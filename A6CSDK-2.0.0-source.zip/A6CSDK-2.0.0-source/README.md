# A6 C SDK 2.0.0

频道：**@a6wzneihe**

本包只提供 C 档的读取、指令分析和本地模拟核心源码。游戏定位层已经移出：包内不携带游戏模块标识、版本地址表、人物枚举代码或固定游戏字段配置。调用方必须先取得当前会话的输入，再交给 SDK。

这是纯源码包，不包含预编译静态库、动态库或可执行文件。依赖也以源码归档形式提供。

接口版本为 **2**。这是一次不兼容的接口更新，接入项目必须按本页重新编译；旧头文件不能与新库混用。主程序的其他坐标模块不在本包中。

## 文件

- `include/A6C.h`：C ABI、运行时输入和结果结构。
- `include/A6C.hpp`：C++17 生命周期包装。
- `examples/A6C_example.cpp`：调用方适配入口，不含真实地址或游戏定位实现。
- `src/`：C 核心和调用方输入接口的完整实现。
- `third_party/sources/`：构建所需的第三方源码归档。
- `MANIFEST.json`、`SHA256SUMS.txt`：包内文件清单与校验。

## 调用顺序

1. 通过 `A6C_Create` 提供同步内存读取回调。映射列表和进程启动标识回调可选，省略时读取 `/proc` 元数据。
2. 调用方定位并确认当前进程、会话、五个目标对象和两个函数指针槽。
3. 填写 `A6C_Binding`，通过 `A6C_Bind` 提交。SDK 复制所有输入和校验字节，调用返回后原数组可释放。
4. 工作线程反复调用 `A6C_Poll`。只有 `status == A6C_READY && count == 5` 才能使用坐标。
5. 进程、会话或对象归属变化时，调用方重新定位，增加 `epoch` 并重新绑定。`A6C_Reset` 会清空绑定；之后需要重新调用 `A6C_Bind`。

```cpp
#include "A6C.hpp"

// A6 | @a6wzneihe: 由接入项目实现，只有完整读取才返回 1。
int A6C_Read(void* context, int32_t pid, uint64_t address,
             void* output, size_t size);

// A6 | @a6wzneihe: current 及其 guard 字节由调用方准备并验证。
void A6C_ReadOne(void* driver, const A6C_Binding& current) {
    A6C_Config config{};
    config.struct_size = sizeof(config);
    config.abi_version = A6C_ABI_VERSION;
    config.context = driver;
    config.read_memory = A6C_Read;
    A6C::A6C_Session session(config);
    session.A6C_Bind(current);
    const auto frame = session.A6C_Poll();
    if (frame.status == A6C_READY && frame.count == A6C_MAX_POINTS) {
        // A6 | @a6wzneihe: frame.points 是本次校验通过的输出。
    }
}
```

实际连续采集应复用同一个 session，避免每帧创建和销毁。完整可编译的占位示例在 `examples/`，默认不会连接任何进程。

## 运行时输入

| 字段 | 调用方需要提供的内容 |
| --- | --- |
| `pid`、`start_ticks` | 当前进程及其启动标识；PID 相同而启动标识不同也必须重绑。 |
| `epoch` | 调用方的会话代次，非零；输入变化时必须更新。 |
| `access_slot` | 当前访问入口的 8 字节函数指针槽的绝对地址。 |
| `publish_slot` | 当前发布入口的 8 字节函数指针槽的绝对地址。 |
| `targets[5]` | 五个当前目标的人物标识、阵营、人物地址和位置对象地址；顺序决定输出顺序。 |
| `guards` | 调用方已经确认的稳定内存及其预期字节。 |

地址必须是当前进程的规范化地址，不是相对偏移，不可来自以前的进程或会话。两个槽必须是不同的有效地址；SDK 在运行时读取其中的实际入口。五个人物地址和位置对象地址各自唯一、阵营一致且有效；`actor_key` 仅原样输出，不额外假设其全局唯一。

`guards` 必须覆盖会话身份、人物到位置对象的归属关系以及所选入口的归属。**定位和这些关系的真实性由调用方负责**，本包没有这些结构的先验定义。不能用一个无关且一直不变的内存值替代全部归属检查。使用稳定元数据，不要把持续变化的坐标或发布阶段位作为固定预期值。

支持 1～64 个不重叠 guard，每个 1～256 字节，总计不超过 4096 字节。SDK 在采样开始和发布结果前核对预期字节，并另外校验采样过程中的读取一致性。进程或预期字节变化时返回 `A6C_GENERATION_CHANGED`，坐标清零。

同一输入重复绑定不会清空 C 核心缓存。相同进程、启动标识和 epoch 下改变输入会被拒绝；拒绝不会覆盖原绑定。不同 session 彼此独立；同一 session 并发或重入调用返回 `A6C_BUSY`。销毁前必须结束该 session 的全部调用。

## 输出和边界

- `x/z` 是平面坐标，`height` 是高度，保留原始整数单位。
- `binding_epoch` 是调用方提交的代次；`generation` 是 SDK 内部绑定代次。
- `record_address` 只描述本帧来源，不是永久有效的明文指针。
- 失败帧不会保留上次坐标；未绑定时返回 `A6C_NOT_BOUND`。
- `A6C_READ_ERROR` 表示读取失败；`A6C_WAITING` 表示等待一致输入或完整发布；`A6C_UNSUPPORTED` 表示当前可执行结构超出核心支持范围。
- SDK 不负责显示平滑、预测、绘制、登录、网络通信或更新。

删除定位层不等于自动兼容任意游戏版本。调用方仍须验证目标版本，当前指令和发布格式也必须能被 C 核心识别。SDK 会本地分析和模拟当前读取到的代码，保留所需的通用指令语义和发布数据校验。

## 运行依赖

构建目标为 Android `arm64-v8a`、API 24+。内存只通过 `read_memory` 回调读取；SDK 不提供驱动、root 获取或目标写入接口。C 核心使用的 libc 文件、文件描述符内容及元数据、相应路径的 GPU 元数据仍按原核心读取，需要进程权限允许。模拟写入仅发生在本地副本。

Capstone 和 Unicorn 是必要依赖。构建时从随包源码归档解压并编译，不从网络下载，也不依赖预编译库。保留第三方许可证和源码材料。A6 命名及频道用于来源标识，不构成防逆向承诺。

## 构建和离线测试

```sh
python tools/A6C_build_android.py \
  --ndk /path/to/android-ndk \
  --cmake /path/to/cmake --ninja /path/to/ninja \
  --build /path/to/a6c-build
```

CMake 提供 `A6C::static` 和 `A6C::shared` 构建目标，调用方可按项目需要链接。首次构建会同时编译依赖，产物仅生成在指定构建目录。

Windows 构建还需要 PATH 中有 POSIX `sh`、`sed`、`grep` 等基础工具，可使用 Git Bash；`A6C_build_android.py` 会为依赖探测指定 NDK 的目标工具。直接调用 CMake 时也需设置相应工具环境。

`A6C_binding_test` 检查输入复制、范围、代次和非法绑定；`A6C_contract_test` 使用合成内存和简短测试指令验证接口、五点输出、旧身份拒绝及重绑。两者都不连接游戏，也不证明某一真实对局已经通过验收。
