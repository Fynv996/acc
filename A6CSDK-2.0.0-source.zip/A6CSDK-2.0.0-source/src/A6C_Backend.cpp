// A6 C SDK | exact read callback plus optional /proc metadata | @a6wzneihe
#include "internal/A6C_Internal.hpp"
#include <algorithm>
#include <charconv>
#include <fstream>
#include <sstream>
#include <stdexcept>
namespace A6CAdapter {
namespace {
class A6C_CallbackBackend final:public A6CInternal::A6CBackend {
    A6C_Config config_;
    // A6 SDK | @a6wzneihe
    static std::uint64_t A6C_ParseHex(const std::string& text) {
        std::uint64_t value=0;const auto p=std::from_chars(text.data(),text.data()+text.size(),value,16);
        if(p.ec!=std::errc{}||p.ptr!=text.data()+text.size())throw std::runtime_error("A6 mapping format");return value;
    }
    // A6 SDK | @a6wzneihe
    static std::uint64_t A6C_ProcIdentity(int pid) {
        if(pid<=0)return 0;std::ifstream input("/proc/"+std::to_string(pid)+"/stat");std::string line;
        if(!std::getline(input,line))return 0;const auto end=line.rfind(')');if(end==line.npos)return 0;
        std::istringstream fields(line.substr(end+1));std::string value;
        for(unsigned i=0;i<=19;++i)if(!(fields>>value))return 0;
        std::uint64_t ticks=0;const auto p=std::from_chars(value.data(),value.data()+value.size(),ticks);
        return p.ec==std::errc{}&&p.ptr==value.data()+value.size()?ticks:0;
    }
public:
    // A6 SDK | @a6wzneihe
    explicit A6C_CallbackBackend(const A6C_Config& config):config_(config){}
    // A6 SDK | @a6wzneihe
    bool A6C_read(int pid,std::uint64_t address,void* output,std::size_t size)override {
        return pid>0&&output&&size&&address<=UINT64_MAX-size&&config_.read_memory&&
            config_.read_memory(config_.context,pid,address,output,size)==1;
    }
    // A6 SDK | @a6wzneihe
    std::vector<A6CInternal::A6CMapping> A6C_maps(int pid)override {
        std::vector<A6CInternal::A6CMapping> result;
        if(config_.list_mappings){
            struct A6C_Receiver{std::vector<A6CInternal::A6CMapping>* values;bool invalid=false;} receiver{&result};
            const auto sink=[](void* context,const A6C_Mapping* value)->int {
                auto& state=*static_cast<A6C_Receiver*>(context);
                if(!value||value->start>=value->end||!value->permissions||!value->path||state.values->size()>=16384){state.invalid=true;return 0;}
                const std::string permissions(value->permissions),path(value->path);
                if(permissions.size()>8||path.size()>4096){state.invalid=true;return 0;}
                state.values->push_back({value->start,value->end,value->file_offset,permissions,path});return 1;
            };
            if(config_.list_mappings(config_.context,pid,sink,&receiver)!=1||receiver.invalid)throw std::runtime_error("A6 mapping callback failed");
        }else{
            std::ifstream input("/proc/"+std::to_string(pid)+"/maps");std::string line;
            if(!input)throw std::runtime_error("A6 mappings unavailable");
            while(std::getline(input,line)){
                std::istringstream row(line);std::string range,permissions,offset,device,inode,path;
                if(!(row>>range>>permissions>>offset>>device>>inode))throw std::runtime_error("A6 mapping format");
                std::getline(row,path);const auto first=path.find_first_not_of(' ');path=first==path.npos?"":path.substr(first);
                const auto dash=range.find('-');if(dash==range.npos||result.size()>=16384)throw std::runtime_error("A6 mapping range");
                const auto begin=A6C_ParseHex(range.substr(0,dash)),end=A6C_ParseHex(range.substr(dash+1));
                if(begin>=end)throw std::runtime_error("A6 mapping range");
                result.push_back({begin,end,A6C_ParseHex(offset),permissions,path});
            }
        }
        std::sort(result.begin(),result.end(),[](const auto& a,const auto& b){return a.start<b.start;});
        for(std::size_t i=1;i<result.size();++i)if(result[i].start<result[i-1].end)throw std::runtime_error("A6 overlapping mappings");
        return result;
    }
    // A6 SDK | @a6wzneihe
    A6CInternal::A6CThreadIdentity A6C_identity(int pid,int tid)override {
        if(pid!=tid)return {};std::uint64_t ticks=0;
        if(config_.read_identity){if(config_.read_identity(config_.context,pid,&ticks)!=1)ticks=0;}
        else ticks=A6C_ProcIdentity(pid);
        return {ticks?pid:0,ticks,{}};
    }
};
}
// A6 SDK | @a6wzneihe
std::shared_ptr<A6CInternal::A6CBackend> A6C_MakeBackend(const A6C_Config& config) {
    return std::make_shared<A6C_CallbackBackend>(config);
}
}
