// A6 C SDK | stable C ABI | @a6wzneihe
#include "A6C.h"
#include "internal/A6C_Internal.hpp"
#include "internal/A6C_Core.hpp"
#include "internal/A6C_Status.hpp"
#include <mutex>
#include <new>
struct A6C_Handle {
    std::mutex mutex;
    std::shared_ptr<A6CInternal::A6CBackend> backend;
    std::shared_ptr<const A6CInput::A6CBinding> binding;
    A6CCore::A6CReader reader;
    // A6 SDK | @a6wzneihe
    explicit A6C_Handle(std::shared_ptr<A6CInternal::A6CBackend> b)
        :backend(std::move(b)),reader(backend){}
};
namespace {
// A6 SDK | @a6wzneihe
std::uint32_t A6C_ConvertMode(A6CInternal::A6CMode mode) {
    return mode==A6CInternal::A6CMode::plain?A6C_PLAIN:mode==A6CInternal::A6CMode::encrypted?A6C_PROTECTED:A6C_UNKNOWN;
}
}
extern "C" {
// A6 SDK | @a6wzneihe
uint32_t A6C_GetAbiVersion(void){return A6C_ABI_VERSION;}
// A6 SDK | @a6wzneihe
const char* A6C_GetVersion(void){return "A6 C SDK 2.0.0 | @a6wzneihe";}
const char* A6C_GetChannel(void){return "@a6wzneihe";}
int A6C_Create(const A6C_Config* config,A6C_Handle** output) {
    if(output)*output=nullptr;
    if(!config||!output||config->struct_size!=sizeof(A6C_Config)||config->abi_version!=A6C_ABI_VERSION||!config->read_memory)return A6C_INVALID_ARGUMENT;
    try {
        *output=new A6C_Handle(A6CAdapter::A6C_MakeBackend(*config));return A6C_OK;
    }catch(const std::bad_alloc&){return A6C_NO_MEMORY;}catch(...){return A6C_INTERNAL_ERROR;}
}
// A6 SDK | @a6wzneihe
void A6C_Destroy(A6C_Handle* handle){delete handle;}
// A6 SDK | @a6wzneihe
int A6C_Poll(A6C_Handle* handle,A6C_Frame* output) {
    if(!output||output->struct_size!=sizeof(A6C_Frame))return A6C_INVALID_ARGUMENT;
    *output={};output->struct_size=sizeof(*output);output->abi_version=A6C_ABI_VERSION;
    if(!handle)return A6C_INVALID_ARGUMENT;
    std::unique_lock<std::mutex> lock(handle->mutex,std::try_to_lock);if(!lock.owns_lock())return A6C_BUSY;
    if(!handle->binding)return A6C_NOT_BOUND;
    try {
        output->pid=handle->binding->pid;output->binding_epoch=handle->binding->epoch;
        const auto frame=handle->reader.A6C_poll(handle->binding);
        output->mode=A6C_ConvertMode(frame.mode);output->observed_mode=A6C_ConvertMode(frame.observed_encryption);
        output->generation=frame.generation;output->sequence=frame.sequence;output->monotonic_ms=frame.monotonic_ms;
        output->observed_ms=frame.encryption_observed_ms;output->bytes_read=frame.bytes_read;output->reason=std::uint32_t(frame.reason);
        output->detail_code=frame.detail.empty()?0:A6CStatus::A6C_Code(frame.detail.c_str());
        switch(frame.status){
        case A6CInternal::A6CStatusCode::ready:output->status=A6C_READY;break;
        case A6CInternal::A6CStatusCode::unsupported:output->status=A6C_UNSUPPORTED;break;
        case A6CInternal::A6CStatusCode::generation_changed:output->status=A6C_GENERATION_CHANGED;break;
        case A6CInternal::A6CStatusCode::read_error:output->status=A6C_READ_ERROR;break;
        default:output->status=A6C_WAITING;break;
        }
        if(frame.status==A6CInternal::A6CStatusCode::ready&&frame.count==5){
            output->count=5;
            for(unsigned i=0;i<5;++i){const auto& p=frame.points[i];auto& q=output->points[i];
                q.actor_key=p.actor_key;q.camp=p.camp;q.x=p.x;q.height=p.height;q.z=p.y;q.flags=A6C_HEIGHT_VALID;
                q.actor_address=p.actor;q.owner_address=p.object;q.record_address=p.record;}
        }else if(output->status==A6C_READY){output->status=A6C_WAITING;}
        return A6C_OK;
    }catch(const std::bad_alloc&){return A6C_NO_MEMORY;}catch(...){return A6C_INTERNAL_ERROR;}
}
// A6 SDK | @a6wzneihe
int A6C_Reset(A6C_Handle* handle) {
    if(!handle)return A6C_INVALID_ARGUMENT;
    std::unique_lock<std::mutex> lock(handle->mutex,std::try_to_lock);if(!lock.owns_lock())return A6C_BUSY;
    try{handle->reader.A6C_reset();handle->binding.reset();return A6C_OK;}catch(...){return A6C_INTERNAL_ERROR;}
}
// A6 SDK | @a6wzneihe
int A6C_Bind(A6C_Handle* handle,const A6C_Binding* input) {
    if(!handle||!input)return A6C_INVALID_ARGUMENT;
    try{auto binding=A6CInput::A6C_CopyBinding(*input);
        std::unique_lock<std::mutex> lock(handle->mutex,std::try_to_lock);if(!lock.owns_lock())return A6C_BUSY;
        if(handle->binding){
            if(A6CInput::A6C_SameBinding(*handle->binding,*binding))return A6C_OK;
            if(A6CInput::A6C_EpochConflict(*handle->binding,*binding))return A6C_INVALID_BINDING;
        }
        handle->reader.A6C_reset();handle->binding=std::move(binding);return A6C_OK;
    }catch(const std::bad_alloc&){return A6C_NO_MEMORY;}catch(...){return A6C_INVALID_BINDING;}
}
// A6 SDK | @a6wzneihe
const char* A6C_GetErrorName(int error) {
    switch(error){case A6C_OK:return "A6_OK";case A6C_INVALID_ARGUMENT:return "A6_INVALID_ARGUMENT";
    case A6C_INVALID_BINDING:return "A6_INVALID_BINDING";case A6C_NO_MEMORY:return "A6_NO_MEMORY";
    case A6C_BUSY:return "A6_BUSY";case A6C_NOT_BOUND:return "A6_NOT_BOUND";default:return "A6_INTERNAL_ERROR";}
}
}
