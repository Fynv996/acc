// A6 C SDK | host input validation without game locators | @a6wzneihe
#include "internal/A6C_Binding.hpp"
#include <algorithm>
#include <set>
#include <stdexcept>
namespace A6CInput {
namespace {
// A6 | @a6wzneihe: canonical readable address interval for this ABI.
bool A6C_Range(std::uint64_t address,std::size_t size) noexcept {
    constexpr std::uint64_t limit=0x00ffffffffffffffULL;
    return size&&address>=0x10000&&address<=limit&&size<=limit-address;
}
// A6 | @a6wzneihe: accept only already-normalized pointer-sized locations.
bool A6C_Pointer(std::uint64_t address) noexcept {
    return A6C_Range(address,8)&&!(address&7);
}
// A6 | @a6wzneihe: validation throws before any live session is replaced.
void A6C_Require(bool value) {
    if(!value)throw std::invalid_argument("A6 invalid binding");
}
}
std::shared_ptr<const A6CBinding> A6C_CopyBinding(const A6C_Binding& source) {
    A6C_Require(source.struct_size==sizeof(source)&&source.abi_version==A6C_ABI_VERSION);
    A6C_Require(source.pid>0&&source.start_ticks&&source.epoch&&source.target_count==A6C_MAX_POINTS);
    A6C_Require(A6C_Pointer(source.access_slot)&&A6C_Pointer(source.publish_slot)&&source.access_slot!=source.publish_slot);
    A6C_Require(source.guards&&source.guard_count&&source.guard_count<=64);
    auto output=std::make_shared<A6CBinding>();
    output->pid=source.pid;output->start_ticks=source.start_ticks;output->epoch=source.epoch;
    output->access_slot=source.access_slot;output->publish_slot=source.publish_slot;
    std::set<std::uint64_t> actors,objects;
    for(unsigned i=0;i<A6C_MAX_POINTS;++i) {
        const auto& target=source.targets[i];
        A6C_Require((target.camp==1||target.camp==2)&&target.camp==source.targets[0].camp);
        A6C_Require(A6C_Pointer(target.actor_address)&&A6C_Pointer(target.object_address));
        A6C_Require(actors.insert(target.actor_address).second&&objects.insert(target.object_address).second);
        output->targets[i]=target;
    }
    std::size_t total=0;
    for(std::size_t i=0;i<source.guard_count;++i) {
        const auto& guard=source.guards[i];
        A6C_Require(guard.expected&&guard.size<=256&&A6C_Range(guard.address,guard.size)&&guard.size<=4096-total);
        const auto* bytes=static_cast<const std::uint8_t*>(guard.expected);
        output->guards.push_back({guard.address,A6CInternal::Bytes(bytes,bytes+guard.size)});total+=guard.size;
    }
    std::sort(output->guards.begin(),output->guards.end(),[](const auto& left,const auto& right){return left.address<right.address;});
    for(std::size_t i=1;i<output->guards.size();++i) {
        const auto& previous=output->guards[i-1];
        A6C_Require(previous.address+previous.expected.size()<=output->guards[i].address);
    }
    return output;
}
bool A6C_SameBinding(const A6CBinding& left,const A6CBinding& right) noexcept {
    if(left.pid!=right.pid||left.start_ticks!=right.start_ticks||left.epoch!=right.epoch||
       left.access_slot!=right.access_slot||left.publish_slot!=right.publish_slot||left.guards.size()!=right.guards.size())return false;
    for(unsigned i=0;i<A6C_MAX_POINTS;++i) {
        const auto& a=left.targets[i];const auto& b=right.targets[i];
        if(a.actor_key!=b.actor_key||a.camp!=b.camp||a.actor_address!=b.actor_address||a.object_address!=b.object_address)return false;
    }
    for(std::size_t i=0;i<left.guards.size();++i)
        if(left.guards[i].address!=right.guards[i].address||left.guards[i].expected!=right.guards[i].expected)return false;
    return true;
}
bool A6C_EpochConflict(const A6CBinding& left,const A6CBinding& right) noexcept {
    return left.pid==right.pid&&left.start_ticks==right.start_ticks&&left.epoch==right.epoch&&!A6C_SameBinding(left,right);
}
}
