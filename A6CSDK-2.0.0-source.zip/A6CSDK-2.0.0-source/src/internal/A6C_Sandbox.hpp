// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include "internal/A6C_Analysis.hpp"
#include <memory>
#include <unicorn/unicorn.h>
namespace A6CInternal::detail {
constexpr U Scratch=0x400000000000ULL, Stop=Scratch+0x1F000;
class A6CSandbox {
    uc_engine *cpu_ = nullptr;
    Read read_;
    std::set<U> pages_, allowed_;
    std::map<U, std::uint8_t> loaded_, shadow_;
    std::map<U, std::function<void(A6CSandbox &)>> stubs_;
    std::map<U, std::function<void(A6CSandbox &)>> boundaries_;
    std::set<U> stops_;
    bool failed_ = false;
    std::string failure_;
    uc_context *baseline_ = nullptr;
    bool immutable_operands_ = false;
    // A6 SDK | @a6wzneihe
    void A6C_check(uc_err e) {
        if (e != UC_ERR_OK) throw std::runtime_error(std::string("Unicorn: ") + uc_strerror(e));
    }
    // A6 SDK | @a6wzneihe
    bool A6C_scratch(U a, std::size_t n) {
        return a >= Scratch && a < Scratch + 0x20000 && n <= Scratch + 0x20000 - a;
    }
    template <class F> void A6C_guarded(F f) {
        try {
            f();
        } catch (const std::exception &e) {
            failed_ = true;
            try { failure_ = e.what(); } catch (...) {}
            uc_emu_stop(cpu_);
        }
    }
    // A6 SDK | @a6wzneihe
    static void A6C_code_hook(uc_engine *, U a, uint32_t, void *data) {
        auto &s = *static_cast<A6CSandbox *>(data);
        s.A6C_guarded([&] {
            if (s.stops_.count(a)) { uc_emu_stop(s.cpu_); return; }
            auto boundary = s.boundaries_.find(a);
            if (boundary != s.boundaries_.end()) { boundary->second(s); return; }
            auto it = s.stubs_.find(a);
            if (it != s.stubs_.end()) {
                it->second(s);
                s.A6C_reg(UC_ARM64_REG_PC, s.A6C_reg(UC_ARM64_REG_LR));
                return;
            }
            A6C_require(s.allowed_.count(a), "");
        });
    }
    // A6 SDK | @a6wzneihe
    static bool A6C_unmapped(uc_engine *, uc_mem_type type, U a, int n, int64_t, void *data) {
        auto &s = *static_cast<A6CSandbox *>(data);
        if (type == UC_MEM_FETCH_UNMAPPED) {
            s.failed_ = true;
            try { s.failure_ = "unmapped instruction fetch"; } catch (...) {}
            return false;
        }
        bool ok = true;
        s.A6C_guarded([&] {
            A6C_require(n > 0 && n <= 16, "");
            s.A6C_map(a, n);
        });
        if (s.failed_)
            ok = false;
        return ok;
    }
    // A6 SDK | @a6wzneihe
    static void A6C_read_hook(uc_engine *, uc_mem_type, U a, int n, int64_t, void *data) {
        auto &s = *static_cast<A6CSandbox *>(data);
        s.A6C_guarded([&] {
            if (s.A6C_scratch(a, n))
                return;
            A6C_require(n > 0 && n <= 16, "");
            bool missing = false;
            for (int k = 0; k < n; ++k)
                if (!s.loaded_.count(a + k) && !s.shadow_.count(a + k))
                    missing = true;
            if (missing) {
                auto b = s.read_(a, n, "");
                A6C_require(b.size() == std::size_t(n), "");
                for (int k = 0; k < n; ++k)
                    if (!s.loaded_.count(a + k))
                        s.loaded_[a + k] = b[k];
            }
            Bytes b(n);
            for (int k = 0; k < n; ++k)
                b[k] = s.shadow_.count(a + k) ? s.shadow_.at(a + k) : s.loaded_.at(a + k);
            s.A6C_check(uc_mem_write(s.cpu_, a, b.data(), b.size()));
        });
    }
    // A6 SDK | @a6wzneihe
    static void A6C_write_hook(uc_engine *, uc_mem_type, U a, int n, int64_t v, void *data) {
        auto &s = *static_cast<A6CSandbox *>(data);
        s.A6C_guarded([&] {
            if (s.A6C_scratch(a, n))
                return;
            A6C_require(!s.immutable_operands_, "");
            A6C_require(n > 0 && n <= 8, "");
            auto b = A6C_raw(v, n);
            for (int k = 0; k < n; ++k)
                s.shadow_[a + k] = b[k];
        });
    }

  public:
    // A6 SDK | @a6wzneihe
    A6CSandbox(const std::map<U, Bytes> &code, const std::map<U, U> &words, Read read) : read_(read) {
        A6C_check(uc_open(UC_ARCH_ARM64, UC_MODE_ARM, &cpu_));
        try {
            A6C_map(Scratch, 0x20000);
            A6C_poke(Stop, Bytes{0xc0, 0x03, 0x5f, 0xd6});
            for (auto &[a, b] : code) {
                A6C_map(a, b.size());
                A6C_check(uc_mem_write(cpu_, a, b.data(), b.size()));
                for (std::size_t k = 0; k < b.size(); ++k)
                    loaded_[a + k] = b[k];
                for (std::size_t k = 0; k < b.size(); k += 4)
                    allowed_.insert(a + k);
            }
            for (auto &[a, v] : words)
                A6C_poke(a, A6C_raw(v));
            uc_hook h;
            A6C_check(uc_hook_add(cpu_, &h, UC_HOOK_CODE, (void *)A6C_code_hook, this, 1, 0));
            A6C_check(uc_hook_add(cpu_, &h, UC_HOOK_MEM_READ, (void *)A6C_read_hook, this, 1, 0));
            A6C_check(uc_hook_add(cpu_, &h, UC_HOOK_MEM_WRITE, (void *)A6C_write_hook, this, 1, 0));
            A6C_check(uc_hook_add(cpu_, &h, UC_HOOK_MEM_UNMAPPED, (void *)A6C_unmapped, this, 1, 0));
        } catch (...) {
            uc_close(cpu_);
            cpu_ = nullptr;
            throw;
        }
    }
    // A6 SDK | @a6wzneihe
    ~A6CSandbox() {
        if (baseline_) uc_context_free(baseline_);
        if (cpu_)
            uc_close(cpu_);
    }
    A6CSandbox(const A6CSandbox &) = delete;
    // Decoder-only reuse: operands/code stay immutable, while every replay
    // starts with clean registers, flags, stack and descriptor/data memory.
    // A6 SDK | @a6wzneihe
    void A6C_prepare_decoder_replay() {
        if (!baseline_) {
            A6C_check(uc_context_alloc(cpu_, &baseline_));
            A6C_check(uc_context_save(cpu_, baseline_));
            immutable_operands_ = true;
        } else {
            A6C_check(uc_context_restore(cpu_, baseline_));
        }
        static const Bytes scratch_image = [] {
            Bytes b(0x20000);
            b[Stop - Scratch] = 0xc0;
            b[Stop - Scratch + 1] = 0x03;
            b[Stop - Scratch + 2] = 0x5f;
            b[Stop - Scratch + 3] = 0xd6;
            return b;
        }();
        A6C_check(uc_mem_write(cpu_, Scratch, scratch_image.data(), scratch_image.size()));
        shadow_.clear();
    }
    // A6 SDK | @a6wzneihe
    void A6C_map(U a, std::size_t n) {
        A6C_require(n > 0 && n <= 0x20000 && a <= UINT64_MAX - n, "");
        for (U p = a & ~U(4095); p < a + n; p += 4096)
            if (pages_.insert(p).second)
                A6C_check(uc_mem_map(cpu_, p, 4096, UC_PROT_ALL));
    }
    // A6 SDK | @a6wzneihe
    void A6C_poke(U a, const Bytes &b) {
        A6C_map(a, b.size());
        A6C_check(uc_mem_write(cpu_, a, b.data(), b.size()));
        for (std::size_t k = 0; k < b.size(); ++k)
            shadow_[a + k] = b[k];
    }
    // A6 SDK | @a6wzneihe
    void A6C_stub(U a, std::function<void(A6CSandbox &)> f) {
        A6C_poke(a, Bytes{0xc0, 0x03, 0x5f, 0xd6});
        stubs_[a] = std::move(f);
    }
    // A6 SDK | @a6wzneihe
    void A6C_boundary(U a, std::function<void(A6CSandbox &)> f) {
        A6C_require(allowed_.count(a), "boundary outside captured code");
        boundaries_[a] = std::move(f);
    }
    // A6 SDK | @a6wzneihe
    void A6C_stop_at(U a) { stops_.insert(a); }
    // A6 SDK | @a6wzneihe
    void A6C_clear_stops() { stops_.clear(); }
    // A6 SDK | @a6wzneihe
    U A6C_reg(int r) {
        U v = 0;
        A6C_check(uc_reg_read(cpu_, r, &v));
        return v;
    }
    // A6 SDK | @a6wzneihe
    void A6C_reg(int r, U v) { A6C_check(uc_reg_write(cpu_, r, &v)); }
    // A6 SDK | @a6wzneihe
    U A6C_q(U a) {
        U v = 0;
        A6C_check(uc_mem_read(cpu_, a, &v, 8));
        return v;
    }
    // A6 SDK | @a6wzneihe
    U A6C_run(U entry, U x0 = 0, U x1 = 0, unsigned limit = 20000) {
        failed_ = false;
        failure_.clear();
        A6C_reg(UC_ARM64_REG_SP, Scratch + 0x1E000);
        A6C_reg(UC_ARM64_REG_LR, Stop);
        A6C_reg(UC_ARM64_REG_X0, x0);
        A6C_reg(UC_ARM64_REG_X1, x1);
        auto e = uc_emu_start(cpu_, entry, Stop, 0, limit);
        A6C_require(!failed_, failure_);
        A6C_check(e);
        A6C_require(A6C_reg(UC_ARM64_REG_PC) == Stop || stops_.count(A6C_reg(UC_ARM64_REG_PC)), "instruction budget exhausted");
        return A6C_reg(UC_ARM64_REG_X0);
    }
};
}
