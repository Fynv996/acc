// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include <algorithm>
#include <array>
#include <capstone/capstone.h>
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>

namespace A6CInternal::detail {
using U = std::uint64_t;
using Bytes = std::vector<std::uint8_t>;
using Read = std::function<Bytes(U, std::size_t, const std::string &)>;
constexpr U Stack = 0x400000000000ULL, TagMask = 0x00FFFFFFFFFFFFFFULL;
// A6 SDK | @a6wzneihe
inline std::string A6C_check_location(const std::string& why, const char* file, unsigned line) {
    const char* base = file;
    for (const char* p = file; *p; ++p)
        if (*p == '/' || *p == '\\') base = p + 1;
    return std::string(base) + ":" + std::to_string(line) +
           (why.empty() ? ": check failed" : ": " + why);
}
// A6 SDK | @a6wzneihe
inline void A6C_require(bool ok, const std::string &why,
                    const char* file = __builtin_FILE(), unsigned line = __builtin_LINE()) {
    if (!ok)
        throw std::runtime_error(A6C_check_location(why, file, line));
}
template <class T> T A6C_one(const std::set<T> &s, const std::string &why,
                        const char* file = __builtin_FILE(), unsigned line = __builtin_LINE()) {
    A6C_require(s.size() == 1, "candidate count=" + std::to_string(s.size()) + " " + why, file, line);
    return *s.begin();
}
// A6 SDK | @a6wzneihe
inline U A6C_number(const Bytes &b) {
    A6C_require(!b.empty() && b.size() <= 8, "");
    U v = 0;
    for (std::size_t i = 0; i < b.size(); ++i)
        v |= U(b[i]) << (i * 8);
    return v;
}
// A6 SDK | @a6wzneihe
inline Bytes A6C_raw(U v, std::size_t n = 8) {
    Bytes b(n);
    for (std::size_t i = 0; i < n; ++i)
        b[i] = v >> (i * 8);
    return b;
}
// A6 SDK | @a6wzneihe
inline bool A6C_starts(const std::string &s, const std::string &p) { return s.rfind(p, 0) == 0; }
// A6 SDK | @a6wzneihe
inline bool A6C_ends(const std::string &s, const std::string &p) {
    return s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0;
}
struct A6CInstruction {
    U address = 0;
    std::array<std::uint8_t, 4> bytes{};
    std::string name, text;
    cs_arm64 a{};
    std::vector<unsigned> writes;
    // A6 SDK | @a6wzneihe
    const cs_arm64_op &A6C_op(std::size_t n) const {
        A6C_require(n < a.op_count, "operand " + std::to_string(n) + " of " + name + " " + text +
                " at " + std::to_string(address));
        return a.operands[n];
    }
};
class A6CDisassembler {
    csh handle_ = 0;

  public:
    // A6 SDK | @a6wzneihe
    A6CDisassembler() {
        A6C_require(cs_open(CS_ARCH_ARM64, CS_MODE_ARM, &handle_) == CS_ERR_OK, "");
        cs_option(handle_, CS_OPT_DETAIL, CS_OPT_ON);
    }
    // A6 SDK | @a6wzneihe
    ~A6CDisassembler() { cs_close(&handle_); }
    A6CDisassembler(const A6CDisassembler &) = delete;
    // A6 SDK | @a6wzneihe
    std::string A6C_reg(unsigned r) const {
        auto p = cs_reg_name(handle_, r);
        return p ? p : "";
    }
    // A6 SDK | @a6wzneihe
    std::string A6C_norm(unsigned r) const {
        auto n = A6C_reg(r);
        if (n == "fp")
            return "x29";
        if (n == "lr")
            return "x30";
        if (n == "wsp")
            return "sp";
        if (n.size() > 1 && n[0] == 'w' && n[1] >= '0' && n[1] <= '9')
            n[0] = 'x';
        return n;
    }
    // A6 SDK | @a6wzneihe
    A6CInstruction A6C_decode(const Bytes &b, U pc) const {
        A6C_require(b.size() == 4, "");
        cs_insn *p = nullptr;
        A6C_require(cs_disasm(handle_, b.data(), 4, pc, 1, &p) == 1, "");
        A6CInstruction i;
        i.address = pc;
        i.name = p->mnemonic;
        i.text = p->op_str;
        i.a = p->detail->arm64;
        std::copy(b.begin(), b.end(), i.bytes.begin());
        cs_regs rr, ww;
        uint8_t nr = 0, nw = 0;
        if (cs_regs_access(handle_, p, rr, &nr, ww, &nw) == CS_ERR_OK)
            i.writes.assign(ww, ww + nw);
        cs_free(p, 1);
        return i;
    }
};
struct A6CValue {
    enum Kind { unknown, constants, load } kind = unknown;
    std::set<U> values;
    unsigned size = 0;
    bool indexed = false;
    // A6 SDK | @a6wzneihe
    static A6CValue A6C_constant(U n) {
        A6CValue v;
        v.kind = constants;
        v.values.insert(n);
        return v;
    }
    // A6 SDK | @a6wzneihe
    static A6CValue A6C_loaded(std::set<U> a, unsigned n, bool ix) {
        A6CValue v;
        v.kind = load;
        v.values = std::move(a);
        v.size = n;
        v.indexed = ix;
        return v;
    }
    // A6 SDK | @a6wzneihe
    bool operator==(const A6CValue &b) const {
        return std::tie(kind, values, size, indexed) ==
               std::tie(b.kind, b.values, b.size, b.indexed);
    }
    // A6 SDK | @a6wzneihe
    bool operator!=(const A6CValue &b) const { return !(*this == b); }
};
// A6 SDK | @a6wzneihe
inline A6CValue A6C_merge(A6CValue a, const A6CValue &b) {
    if (a == b)
        return a;
    if (a.kind == b.kind && a.kind != A6CValue::unknown &&
        (a.kind != A6CValue::load || (a.size == b.size && a.indexed == b.indexed))) {
        a.values.insert(b.values.begin(), b.values.end());
        if (a.values.size() <= 8)
            return a;
    }
    return {};
}
struct A6CState {
    std::map<std::string, A6CValue> regs;
    std::map<std::pair<U, unsigned>, A6CValue> stack;
    // A6 SDK | @a6wzneihe
    A6CValue A6C_get(const std::string &r) const {
        auto i = regs.find(r);
        return i == regs.end() ? A6CValue{} : i->second;
    }
    // A6 SDK | @a6wzneihe
    A6CValue A6C_slot(U a, unsigned n) const {
        auto i = stack.find({a, n});
        return i == stack.end() ? A6CValue{} : i->second;
    }
    // A6 SDK | @a6wzneihe
    A6CState A6C_merged(const A6CState &b) const {
        A6CState c;
        for (auto &[k, v] : regs)
            c.regs[k] = A6C_merge(v, b.A6C_get(k));
        for (auto &[k, v] : b.regs)
            if (!regs.count(k))
                c.regs[k] = {};
        for (auto &[k, v] : stack)
            c.stack[k] = A6C_merge(v, b.A6C_slot(k.first, k.second));
        for (auto &[k, v] : b.stack)
            if (!stack.count(k))
                c.stack[k] = {};
        return c;
    }
    // A6 SDK | @a6wzneihe
    bool operator==(const A6CState &b) const { return regs == b.regs && stack == b.stack; }
};
struct A6CGraph {
    U entry = 0;
    std::map<U, A6CInstruction> instructions;
    std::map<U, A6CState> states;
    std::map<U, U> words;
    std::map<U, std::set<U>> edges;
    // A6 SDK | @a6wzneihe
    std::vector<U> A6C_calls() const {
        std::vector<U> r;
        for (auto &[a, i] : instructions)
            if (i.name == "bl")
                r.push_back(i.A6C_op(0).imm);
        return r;
    }
};
class A6CReferenceGraph {
    Read read_;
    U begin_, end_;
    unsigned limit_;
    std::map<std::pair<U, unsigned>, Bytes> data_;

  public:
    A6CDisassembler cs;
    std::map<U, A6CInstruction> code;
    // Analysis-only widening of initialized boolean selectors. Used to reach
    // registered callbacks in both initialization paths; never writes memory.
    bool widen_boolean_loads = false;
    // Opt-in only for the getter reader. A signed/unsigned return-code bit
    // shifted into a dispatch index has two exact possible values.
    bool widen_shifted_unknowns = false;
    // A6 SDK | @a6wzneihe
    A6CReferenceGraph(Read r, U a, U b, unsigned limit = 1800)
        : read_(std::move(r)), begin_(a), end_(b), limit_(limit) {}
    // A6 SDK | @a6wzneihe
    A6CValue A6C_ints(A6CValue v) {
        if (v.kind != A6CValue::load)
            return v;
        if (v.size > 8 || v.values.size() > 8)
            return {};
        A6CValue out;
        out.kind = A6CValue::constants;
        for (U a : v.values) {
            if (a < begin_ || a >= end_ || v.size > end_ - a)
                return {};
            auto k = std::make_pair(a, v.size);
            if (!data_.count(k))
                data_[k] = read_(a, v.size, "");
            out.values.insert(A6C_number(data_[k]));
        }
        if(widen_boolean_loads && v.size==1 && !out.values.empty() && *out.values.rbegin()<=1)
            out.values={0,1};
        return out;
    }
    // A6 SDK | @a6wzneihe
    A6CValue A6C_operand(const A6CInstruction &, const cs_arm64_op &o, const A6CState &s, bool deref = false) {
        A6CValue v;
        if (o.type == ARM64_OP_IMM)
            v = A6CValue::A6C_constant(o.imm);
        else if (o.type == ARM64_OP_REG) {
            auto n = cs.A6C_norm(o.reg);
            v = (n == "xzr" || n == "wzr") ? A6CValue::A6C_constant(0) : s.A6C_get(n);
        } else
            return {};
        if (deref)
            v = A6C_ints(v);
        if (widen_shifted_unknowns && v.kind == A6CValue::unknown && o.type == ARM64_OP_REG &&
            (o.shift.type == ARM64_SFT_LSR || o.shift.type == ARM64_SFT_ASR)) {
            const unsigned bits=A6C_starts(cs.A6C_reg(o.reg),"w")?32:64;
            if(o.shift.value==bits-1) {
                v=A6CValue::A6C_constant(0);
                v.values.insert(o.shift.type==ARM64_SFT_LSR?1:(bits==64?~U(0):0xffffffffULL));
                return v;
            }
        }
        if (v.kind == A6CValue::constants) {
            std::set<U> out;
            for (U n : v.values) {
                unsigned e = o.ext;
                if (e) {
                    unsigned bits = std::array<unsigned, 4>{8, 16, 32, 64}[(e - 1) % 4];
                    U m = bits == 64 ? ~U(0) : (U(1) << bits) - 1;
                    n &= m;
                    if (e >= 5 && bits < 64 && n & (U(1) << (bits - 1)))
                        n |= ~m;
                }
                unsigned amount = o.shift.value;
                if (o.shift.type && amount) {
                    if (amount >= 64)
                        return {};
                    if (o.shift.type == ARM64_SFT_LSL)
                        n <<= amount;
                    else if (o.shift.type == ARM64_SFT_LSR)
                        n >>= amount;
                    else if (o.shift.type == ARM64_SFT_ROR)
                        n = (n >> amount) | (n << (64 - amount));
                    else
                        return {};
                }
                out.insert(n);
            }
            v.values = std::move(out);
        }
        return v;
    }
    // A6 SDK | @a6wzneihe
    void A6C_put(const cs_arm64_op &o, A6CState &s, A6CValue v) {
        if (o.type != ARM64_OP_REG)
            return;
        auto n = cs.A6C_norm(o.reg);
        if (n == "xzr" || n == "wzr")
            return;
        if (v.kind == A6CValue::constants && A6C_starts(cs.A6C_reg(o.reg), "w")) {
            std::set<U> out;
            for (U x : v.values)
                out.insert(x & 0xFFFFFFFF);
            v.values = std::move(out);
        }
        s.regs[n] = std::move(v);
    }
    // A6 SDK | @a6wzneihe
    A6CValue A6C_address(const cs_arm64_op &o, const A6CState &s) {
        auto b = s.A6C_get(cs.A6C_norm(o.mem.base));
        if (b.kind != A6CValue::constants)
            return {};
        A6CValue out;
        out.kind = A6CValue::constants;
        if (!o.mem.index) {
            for (U x : b.values)
                out.values.insert(x + o.mem.disp);
            return out;
        }
        auto ix = A6C_ints(s.A6C_get(cs.A6C_norm(o.mem.index)));
        if (ix.kind != A6CValue::constants || b.values.size() * ix.values.size() > 8 ||
            o.shift.value >= 64)
            return {};
        for (U x : b.values)
            for (U y : ix.values) {
                if (A6C_starts(cs.A6C_reg(o.mem.index), "w"))
                    y &= 0xFFFFFFFF;
                if (o.ext == ARM64_EXT_SXTW && y & 0x80000000)
                    y |= 0xFFFFFFFF00000000ULL;
                out.values.insert(x + (y << o.shift.value) + o.mem.disp);
            }
        return out;
    }
    // A6 SDK | @a6wzneihe
    const A6CInstruction &A6C_instruction(U pc) {
        if (!code.count(pc)) {
            A6C_require(pc >= begin_ && pc < end_ && end_ - pc >= 4 && pc % 4 == 0,
                    "");
            code[pc] = cs.A6C_decode(read_(pc, 4, ""), pc);
        }
        return code.at(pc);
    }
    // A6 SDK | @a6wzneihe
    void A6C_step(const A6CInstruction &i, A6CState &s) {
        auto &n = i.name;
        auto args = [&](unsigned x) { return A6C_operand(i, i.A6C_op(x), s); };
        auto calc = [&](A6CValue a, A6CValue b, const std::function<U(U, U)> &fn) {
            A6CValue v;
            if (a.kind == A6CValue::constants && b.kind == A6CValue::constants &&
                a.values.size() * b.values.size() <= 8) {
                v.kind = A6CValue::constants;
                for (U x : a.values)
                    for (U y : b.values)
                        v.values.insert(fn(x, y));
            }
            return v;
        };
        if (n == "mov" || n == "adr" || n == "adrp")
            A6C_put(i.A6C_op(0), s, args(1));
        else if (n == "movk") {
            auto a = args(0);
            U v = U(i.A6C_op(1).imm) << i.A6C_op(1).shift.value, m = U(0xFFFF) << i.A6C_op(1).shift.value;
            A6C_put(i.A6C_op(0), s, calc(a, A6CValue::A6C_constant(v), [&](U x, U y) { return (x & ~m) | y; }));
        } else if (std::set<std::string>{"add", "adds", "sub", "subs", "and", "orr", "eor", "mul",
                                         "lsl", "lsr", "asr", "bic"}
                       .count(n)) {
            auto a = args(1), b = args(2);
            A6CValue v;
            unsigned bits = A6C_starts(cs.A6C_reg(i.A6C_op(0).reg), "w") ? 32 : 64;
            if (a.kind == A6CValue::unknown && b == A6CValue::A6C_constant(bits - 1) &&
                (n == "lsr" || n == "asr")) {
                v = A6CValue::A6C_constant(0);
                v.values.insert(n == "lsr" ? 1 : (bits == 64 ? ~U(0) : (U(1) << bits) - 1));
            }
            if (a.kind == A6CValue::unknown && n == "and" && b.kind == A6CValue::constants &&
                b.values.size() == 1 && *b.values.begin() < 8) {
                v.kind = A6CValue::constants;
                U m = *b.values.begin();
                for (U x = 0; x <= m; ++x)
                    if (!(x & ~m))
                        v.values.insert(x);
            }
            if (a.kind != A6CValue::unknown && b.kind != A6CValue::unknown)
                v = calc(A6C_ints(a), A6C_ints(b), [&](U x, U y) {
                    if (A6C_starts(n, "add"))
                        return x + y;
                    if (A6C_starts(n, "sub"))
                        return x - y;
                    if (n == "and")
                        return x & y;
                    if (n == "orr")
                        return x | y;
                    if (n == "eor")
                        return x ^ y;
                    if (n == "mul")
                        return x * y;
                    if (n == "lsl")
                        return x << (y & 63);
                    if (n == "lsr")
                        return x >> (y & 63);
                    if (n == "asr")
                        return U(std::int64_t(x) >> (y & 63));
                    return x & ~y;
                });
            A6C_put(i.A6C_op(0), s, v);
        } else if (n == "cset" || n == "csetm") {
            auto v = A6CValue::A6C_constant(0);
            v.values.insert(n == "cset" ? 1 : ~U(0));
            A6C_put(i.A6C_op(0), s, v);
        } else if (std::set<std::string>{"cinc", "csinc", "csel", "csinv", "cneg", "cinv"}.count(
                       n)) {
            auto a = args(1), b = (n == "csel" || n == "csinc" || n == "csinv") ? args(2) : a;
            if (b.kind == A6CValue::constants) {
                std::set<U> out;
                for (U x : b.values) {
                    if (n == "cinc" || n == "csinc")
                        ++x;
                    if (n == "cinv" || n == "csinv")
                        x = ~x;
                    if (n == "cneg")
                        x = -x;
                    out.insert(x);
                }
                b.values = out;
            }
            A6C_put(i.A6C_op(0), s, A6C_merge(a, b));
        } else if (n == "bfxil" || n == "bfi" || n == "ubfx" || n == "sbfx") {
            auto a = args(0), b = args(1);
            unsigned shift = i.A6C_op(2).imm, width = i.A6C_op(3).imm;
            A6C_require(width > 0 && width <= 64 && shift < 64, "");
            U mask = width == 64 ? ~U(0) : (U(1) << width) - 1;
            A6CValue v;
            if (b.kind == A6CValue::unknown && (n == "ubfx" || n == "sbfx") && width <= 2) {
                v.kind = A6CValue::constants;
                for (U x = 0; x < (U(1) << width); ++x)
                    v.values.insert(
                        n == "sbfx" ? U((x ^ (U(1) << (width - 1))) - (U(1) << (width - 1))) : x);
            }
            if (b.kind == A6CValue::constants) {
                if (n == "ubfx" || n == "sbfx") {
                    v.kind = A6CValue::constants;
                    for (U x : b.values) {
                        x = (x >> shift) & mask;
                        if (n == "sbfx" && width < 64 && x & (U(1) << (width - 1)))
                            x |= ~mask;
                        v.values.insert(x);
                    }
                } else
                    v = calc(a, b, [&](U x, U y) {
                        return n == "bfxil" ? (x & ~mask) | ((y >> shift) & mask)
                                            : (x & ~(mask << shift)) | ((y & mask) << shift);
                    });
            }
            A6C_put(i.A6C_op(0), s, v);
        } else if (A6C_starts(n, "ldr") || A6C_starts(n, "ldur") || A6C_starts(n, "ldar") ||
                   A6C_starts(n, "ldaxr") || A6C_starts(n, "ldxr") || A6C_starts(n, "str") ||
                   A6C_starts(n, "stur") || A6C_starts(n, "stlr") || n == "ldp" || n == "stp") {
            unsigned mi = (n == "ldp" || n == "stp") ? 2 : 1;
            if (i.a.op_count <= mi || i.A6C_op(mi).type != ARM64_OP_MEM) {
                A6C_put(i.A6C_op(0), s, {});
                return;
            }
            auto loc = A6C_address(i.A6C_op(mi), s);
            unsigned width = A6C_ends(n, "b")                       ? 1
                             : A6C_ends(n, "h")                     ? 2
                             : A6C_starts(cs.A6C_reg(i.A6C_op(0).reg), "w") ? 4
                                                                : 8;
            for (unsigned ix = 0; ix < ((n == "ldp" || n == "stp") ? 2u : 1u); ++ix) {
                std::set<U> locations;
                for (U a : loc.values)
                    locations.insert(a + ix * width);
                if (A6C_starts(n, "ld")) {
                    A6CValue v;
                    std::vector<A6CValue> vals;
                    for (U a : locations)
                        if (a >= Stack - 0x10000 && a <= Stack + 0x1000)
                            vals.push_back(s.A6C_slot(a, width));
                    if (!locations.empty() && vals.size() == locations.size()) {
                        v = vals[0];
                        for (auto &b : vals)
                            v = A6C_merge(v, b);
                    } else if (!locations.empty() && vals.empty())
                        v = A6CValue::A6C_loaded(locations, width, i.A6C_op(mi).mem.index != 0);
                    A6C_put(i.A6C_op(ix), s, v);
                } else
                    for (U a : locations)
                        if (a >= Stack - 0x10000 && a <= Stack + 0x1000)
                            s.stack[{a, width}] = args(ix);
            }
            if (i.a.writeback) {
                auto name = cs.A6C_norm(i.A6C_op(mi).mem.base);
                if (i.a.op_count > mi + 1 && i.A6C_op(mi + 1).type == ARM64_OP_IMM)
                    s.regs[name] = calc(s.A6C_get(name), A6CValue::A6C_constant(i.A6C_op(mi + 1).imm),
                                        [](U x, U y) { return x + y; });
                else
                    s.regs[name] = loc;
            }
        } else if (n == "bl" || n == "blr") {
            for (unsigned x = 0; x < 19; ++x)
                s.regs["x" + std::to_string(x)] = {};
            s.regs["x30"] = {};
        } else if (std::set<std::string>{"br", "b", "ret", "cmp", "cmn", "tst", "ccmp", "nop",
                                         "dsb", "isb", "clrex"}
                       .count(n) ||
                   A6C_starts(n, "b.") || A6C_starts(n, "cb") || A6C_starts(n, "tb")) {
        } else
            for (unsigned r : i.writes)
                s.regs[cs.A6C_norm(r)] = {};
    }
    // A6 SDK | @a6wzneihe
    A6CGraph A6C_walk(U entry) {
        A6CGraph g;
        g.entry = entry;
        g.states[entry].regs["sp"] = A6CValue::A6C_constant(Stack);
        std::deque<U> queue{entry};
        unsigned count = 0;
        while (!queue.empty()) {
            A6C_require(++count <= limit_ * 25 && g.instructions.size() <= limit_,
                    "");
            U a = queue.front();
            queue.pop_front();
            auto s = g.states[a];
            auto i = A6C_instruction(a);
            g.instructions[a] = i;
            auto n = i.name;
            std::set<U> targets;
            if (n == "ret" || n == "brk" || n == "hlt" || n == "udf") {
            } else if (n == "b")
                targets.insert(i.A6C_op(0).imm);
            else if (A6C_starts(n, "b.") || A6C_starts(n, "cb") || A6C_starts(n, "tb")) {
                targets.insert(a + 4);
                targets.insert(i.A6C_op(i.a.op_count - 1).imm);
            } else if (n == "br") {
                auto v = A6C_operand(i, i.A6C_op(0), s);
                if (v.kind == A6CValue::load && v.indexed && v.size == 8) {
                    for (U p : v.values) {
                        A6C_require(p >= begin_ && p < end_ && end_ - p >= 8,
                                "");
                        if (!g.words.count(p))
                            g.words[p] = A6C_number(read_(p, 8, ""));
                        targets.insert(g.words[p]);
                    }
                } else if (v.kind == A6CValue::constants)
                    targets = v.values;
            } else
                targets.insert(a + 4);
            g.edges[a] = targets;
            A6C_step(i, s);
            for (U t : targets) {
                if (t < begin_ || t >= end_)
                    continue;
                auto it = g.states.find(t);
                A6CState joined = it == g.states.end() ? s : it->second.A6C_merged(s);
                if (it == g.states.end() || !(it->second == joined)) {
                    g.states[t] = joined;
                    queue.push_back(t);
                }
            }
        }
        return g;
    }
};
// A6 SDK | @a6wzneihe
inline U A6C_scalar(const A6CValue &v, const std::string &why) {
    A6C_require(v.kind == A6CValue::constants, "" + why);
    return A6C_one(v.values, why);
}
// A6 SDK | @a6wzneihe
inline U A6C_load_address(const A6CValue &v, unsigned size, const std::string &why) {
    A6C_require(v.kind == A6CValue::load && v.size == size, "" + why);
    return A6C_one(v.values, why);
}
} // namespace pure_signal::detail
