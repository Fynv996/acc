// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <string>

// Production status text is an opaque, stable identifier. The diagnostic
// build keeps explanations; both representations retain the same wire code.
#ifndef A6_PRIVATE_STATUS_TEXT
#if defined(A6_PRODUCTION_BUILD) && A6_PRODUCTION_BUILD && (!defined(A6_DIAGNOSTICS) || !A6_DIAGNOSTICS)
#define A6_PRIVATE_STATUS_TEXT 1
#else
#define A6_PRIVATE_STATUS_TEXT 0
#endif
#endif

namespace A6CStatus {
inline constexpr std::uint64_t seed = 14695981039346656037ULL;
// A6 SDK | @a6wzneihe
constexpr std::uint64_t A6C_Hash(const char* text, std::uint64_t value = seed) noexcept {
    if (text) while (*text) { value ^= static_cast<unsigned char>(*text++); value *= 1099511628211ULL; }
    return value;
}
// A6 SDK | @a6wzneihe
constexpr int A6C_Digit(char c) noexcept {
    return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1;
}
// A6 SDK | @a6wzneihe
inline bool A6C_Parse(const char* text, std::uint64_t& value) noexcept {
    if (!text || *text++ != '~') return false;
    value = 0;
    for (unsigned i = 0; i < 16; ++i) {
        const int digit = A6C_Digit(*text++);
        if (digit < 0) return false;
        value = (value << 4) | static_cast<unsigned>(digit);
    }
    return *text == '\0';
}
// A6 SDK | @a6wzneihe
inline std::uint64_t A6C_Code(const char* text) noexcept {
    std::uint64_t value = 0;
    return A6C_Parse(text, value) ? value : A6C_Hash(text);
}
struct A6CText {
    std::array<char, 18> bytes{};
    // A6 SDK | @a6wzneihe
    constexpr explicit A6CText(std::uint64_t value) noexcept {
        bytes[0] = '~';
        for (unsigned i = 0; i < 16; ++i) {
            const unsigned digit = static_cast<unsigned>((value >> (60 - i * 4)) & 15);
            bytes[i + 1] = static_cast<char>(digit < 10 ? '0' + digit : 'a' + digit - 10);
        }
    }
};
// A6 SDK | @a6wzneihe
inline std::string A6C_Join(const char* prefix, const std::string& suffix) {
    std::uint64_t value = 0;
    if (!A6C_Parse(prefix, value)) return std::string(prefix) + suffix;
    const A6CText text(A6C_Hash(suffix.c_str(), value));
    return text.bytes.data();
}
template<class A6CReasonCode, A6CReasonCode Default> struct A6CFault : std::runtime_error {
    A6CReasonCode reason;
    // A6 SDK | @a6wzneihe
    explicit A6CFault(const std::string& message, A6CReasonCode why = Default)
        : std::runtime_error(message), reason(why) {}
};
template<unsigned Tag, class Base = std::runtime_error> struct A6CError : Base { using Base::Base; };
struct A6CSilent : std::exception { const char* what() const noexcept override { return ""; } };
} // namespace a6_status

#if A6_PRIVATE_STATUS_TEXT
#define A6_STATUS_TEXT(text) ([]() noexcept -> const char* { \
    static constexpr A6CStatus::A6CText value(A6CStatus::A6C_Hash(text)); return value.bytes.data(); }())
#else
#define A6_STATUS_TEXT(text) text
#endif
