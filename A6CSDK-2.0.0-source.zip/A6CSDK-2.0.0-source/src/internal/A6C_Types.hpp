// A6 C SDK | private callback contract and frame types | @a6wzneihe
#pragma once
#include <array>
#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
namespace A6CInternal {
using Address=std::uint64_t;
using Bytes=std::vector<std::uint8_t>;
struct A6CMapping {Address start=0,end=0,offset=0;std::string permissions,path;};
struct A6CThreadIdentity {int tid=0;std::uint64_t start_ticks=0;std::string name;};
class A6CBackend {
public:
    // A6 SDK | @a6wzneihe
    virtual ~A6CBackend()=default;
    virtual bool A6C_read(int pid,Address address,void* output,std::size_t size)=0;
    virtual std::vector<A6CMapping> A6C_maps(int pid)=0;
    virtual A6CThreadIdentity A6C_identity(int pid,int tid)=0;
};
enum class A6CStatusCode {ready,waiting,generation_changed,unsupported,read_error};
enum class A6CMode {unknown,plain,encrypted};
enum class A6CReasonCode:std::uint8_t {none,other,publication_busy,record_changed,coordinate_identity_changed,identity_changed,record_representation};
struct A6CPoint {std::uint32_t actor_key=0,camp=0;std::int32_t x=0,height=0,y=0;Address actor=0,object=0,record=0;};
struct A6CFrame {
    A6CStatusCode status=A6CStatusCode::waiting;A6CMode mode=A6CMode::unknown;int pid=0;
    std::uint64_t generation=0,sequence=0,monotonic_ms=0,bytes_read=0;
    std::array<A6CPoint,5> points{};std::size_t count=0;std::string detail;
    A6CReasonCode reason=A6CReasonCode::none;bool separate_encryption_status=false;
    A6CMode observed_encryption=A6CMode::unknown;std::uint64_t encryption_observed_ms=0;
};
// A6 SDK | @a6wzneihe
inline std::uint64_t A6C_monotonic_ms()noexcept {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
}
