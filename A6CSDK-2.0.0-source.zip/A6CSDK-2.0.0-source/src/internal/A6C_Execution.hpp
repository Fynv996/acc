// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include "internal/A6C_Status.hpp"
#include <unicorn/unicorn.h>
#include <unicorn/arm64.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <functional>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
namespace A6CExecution {
using U=std::uint64_t;
class A6CMachine {
    uc_engine* cpu=nullptr;
    std::function<bool(U,void*,std::size_t)> source;
    std::set<U> pages,codePages,written;
    std::map<U,unsigned char> loaded;
    std::map<U,unsigned> symbols;
    std::map<U,U> tls;
    U deadline=0;unsigned steps=0;
    std::string failed;
    int target=0;
    U signalHandler=0,pendingFault=0;bool insideSignal=false;
    std::uint32_t syncId=1;
    std::function<bool(U)> signalAddress;
    std::function<bool(U)> executableAddress;
    static constexpr U scratch=0x500000000000ULL,stop=scratch+0x1f000;
    // A6 SDK | @a6wzneihe
    static U A6C_clock(){return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
    // A6 SDK | @a6wzneihe
    bool A6C_local(U a,std::size_t n)const{return a>=scratch&&a<scratch+0x20000&&n<=scratch+0x20000-a;}
    // A6 SDK | @a6wzneihe
    void A6C_check(uc_err e){if(e!=UC_ERR_OK)throw std::runtime_error(uc_strerror(e));}
    // A6 SDK | @a6wzneihe
    void A6C_map(U a,std::size_t n,bool code=false) {
        if(!n||n>0x20000||a>~U(0)-n)throw std::runtime_error(A6_STATUS_TEXT("vm range"));
        for(U p=a&~U(4095);p<a+n;p+=4096){
            if(pages.size()>512)throw std::runtime_error(A6_STATUS_TEXT("C page budget"));
            if(pages.insert(p).second)A6C_check(uc_mem_map(cpu,p,4096,UC_PROT_ALL));
            if(code&&codePages.insert(p).second){
                std::array<unsigned char,4096> raw{};
                for(unsigned at=0;at<4096;at+=256)if(!source(p+at,raw.data()+at,256))throw std::runtime_error(A6_STATUS_TEXT("vm code read"));
                A6C_check(uc_mem_write(cpu,p,raw.data(),raw.size()));
            }
        }
    }
    // A6 SDK | @a6wzneihe
    void A6C_input(U a,std::size_t n) {
        if(A6C_local(a,n))return;
        if(n>256)throw std::runtime_error(A6_STATUS_TEXT("vm operand size"));
        A6C_map(a,n);std::vector<unsigned char> raw(n);
        bool need=false;for(std::size_t k=0;k<n;++k)need|=!written.count(a+k)&&!loaded.count(a+k);
        if(need){if(!source(a,raw.data(),n)){if(signalHandler&&!insideSignal&&signalAddress&&signalAddress(a)){pendingFault=a;uc_emu_stop(cpu);return;}throw std::runtime_error(A6_STATUS_TEXT("vm data read"));}
            for(std::size_t k=0;k<n;++k)if(!written.count(a+k)&&!loaded.count(a+k))loaded[a+k]=raw[k];}
        A6C_check(uc_mem_read(cpu,a,raw.data(),n));
        for(std::size_t k=0;k<n;++k)if(!written.count(a+k))raw[k]=loaded.at(a+k);
        A6C_check(uc_mem_write(cpu,a,raw.data(),n));
    }
    // A6 SDK | @a6wzneihe
    void A6C_fail(const std::string& text){if(failed.empty())failed=text;uc_emu_stop(cpu);}
    // A6 SDK | @a6wzneihe
    static bool A6C_missing(uc_engine*,uc_mem_type type,U a,int n,int64_t,void* value) {
        auto& m=*static_cast<A6CMachine*>(value);try{m.A6C_map(a,std::size_t(n),type==UC_MEM_FETCH_UNMAPPED);return true;}
        catch(const std::exception& e){m.A6C_fail(std::string(e.what())+" address="+std::to_string(a)+" size="+std::to_string(n)+" type="+std::to_string(type));return false;}
    }
    // A6 SDK | @a6wzneihe
    static void A6C_access(uc_engine*,uc_mem_type type,U a,int n,int64_t,void* value) {
        auto& m=*static_cast<A6CMachine*>(value);try{
            if(type==UC_MEM_READ)m.A6C_input(a,std::size_t(n));
            else if(!m.A6C_local(a,n))for(int i=0;i<n;++i)m.written.insert(a+i);
        }catch(const std::exception& e){m.A6C_fail(e.what());}
    }
    // A6 SDK | @a6wzneihe
    static void A6C_code(uc_engine*,U a,uint32_t,void* value) {
        auto& m=*static_cast<A6CMachine*>(value);
        if(m.executableAddress&&!m.executableAddress(a)){m.A6C_fail(A6_STATUS_TEXT("C execution mapping"));return;}
        if(++m.steps>50000||((m.steps&63)==1&&A6C_clock()>m.deadline))m.A6C_fail(A6_STATUS_TEXT("vm budget"));
        try {auto found=m.symbols.find(a);if(found!=m.symbols.end())m.A6C_external(found->second);}
        catch(const std::exception& e){m.A6C_fail(e.what());}
    }
    // A6 SDK | @a6wzneihe
    void A6C_output(U a,const void* bytes,std::size_t n){A6C_map(a,n);A6C_check(uc_mem_write(cpu,a,bytes,n));if(!A6C_local(a,n))for(std::size_t i=0;i<n;++i)written.insert(a+i);}
    // A6 SDK | @a6wzneihe
    void A6C_external(unsigned kind) {
        const auto x0=A6C_reg(UC_ARM64_REG_X0),x1=A6C_reg(UC_ARM64_REG_X1),x2=A6C_reg(UC_ARM64_REG_X2);
        U result=0;
        if(kind==0){result=tls.count(x0)?tls.at(x0):0;}
        else if(kind==1){if(tls.size()>32)throw std::runtime_error(A6_STATUS_TEXT("vm tls budget"));tls[x0]=x1;}
        else if(kind==2){
            if(x1==0xc0300947ULL){
                std::array<unsigned char,48> info{};A6C_read(x2,info.data(),info.size());
                const int pfd=int(::syscall(434,target,0));if(pfd<0)throw std::runtime_error(A6_STATUS_TEXT("vm pidfd open"));
                const int fd=int(::syscall(438,pfd,int(x0),0));close(pfd);if(fd<0)throw std::runtime_error(A6_STATUS_TEXT("vm pidfd duplicate"));
                const int status=ioctl(fd,x1,info.data());close(fd);if(status)throw std::runtime_error(A6_STATUS_TEXT("vm GPU metadata"));
                A6C_output(x2,info.data(),info.size());
            }else if(x1==0xc0100940ULL){std::array<U,2> value{syncId++,0};A6C_output(x2,value.data(),sizeof(value));}
            else if(x1==0xc0100941ULL){}
            else throw std::runtime_error(A6_STATUS_TEXT("vm ioctl ")+std::to_string(x1));
        }
        else if(kind>=3&&kind<=6){
            if(x2>65536)throw std::runtime_error(A6_STATUS_TEXT("vm copy budget"));
            std::vector<unsigned char> a(x2),b(x2);
            auto get=[&](U address,std::vector<unsigned char>& v){for(std::size_t i=0;i<v.size();i+=128)A6C_read(address+i,v.data()+i,std::min<std::size_t>(128,v.size()-i));};
            if(kind==5)std::fill(a.begin(),a.end(),static_cast<unsigned char>(x1));else get(x1,a);
            if(kind==6){get(x0,b);result=static_cast<U>(std::memcmp(b.data(),a.data(),x2));}
            else {A6C_output(x0,a.data(),a.size());result=x0;}
        } else if(kind==7){while(result<65536){unsigned char c=0;A6C_read(x0+result,&c,1);if(!c)break;++result;}if(result==65536)throw std::runtime_error(A6_STATUS_TEXT("vm string budget"));}
        else if(kind==8){result=scratch+0x1000;}
        else throw std::runtime_error(A6_STATUS_TEXT("vm external ")+std::to_string(kind));
        A6C_reg(UC_ARM64_REG_X0,result);A6C_reg(UC_ARM64_REG_PC,A6C_reg(UC_ARM64_REG_LR));
    }
    // A6 SDK | @a6wzneihe
    void A6C_syscall() {
        const auto nr=A6C_reg(UC_ARM64_REG_X8),x0=A6C_reg(UC_ARM64_REG_X0),x1=A6C_reg(UC_ARM64_REG_X1),x2=A6C_reg(UC_ARM64_REG_X2),x3=A6C_reg(UC_ARM64_REG_X3);
        if(target<=0||x0>1048576)throw std::runtime_error(A6_STATUS_TEXT("vm descriptor identity"));
        if(nr==67||nr==80){
            const std::string path="/proc/"+std::to_string(target)+"/fd/"+std::to_string(x0);
            int fd=open(path.c_str(),(nr==67?O_RDONLY:O_PATH)|O_CLOEXEC|O_NONBLOCK);
            if(fd<0)throw std::runtime_error(A6_STATUS_TEXT("vm descriptor unavailable"));
            struct stat value{};bool ok=fstat(fd,&value)==0;
            if(nr==67){
                std::array<unsigned char,8> bytes{};
                ok=ok&&x2==8&&x3==0&&S_ISREG(value.st_mode)&&value.st_size>=8&&pread(fd,bytes.data(),8,0)==8;
                close(fd);if(!ok)throw std::runtime_error(A6_STATUS_TEXT("vm descriptor content"));A6C_output(x1,bytes.data(),8);A6C_reg(UC_ARM64_REG_X0,8);
            }else{
                close(fd);if(!ok)throw std::runtime_error(A6_STATUS_TEXT("vm descriptor metadata"));A6C_output(x1,&value,sizeof(value));A6C_reg(UC_ARM64_REG_X0,0);
            }
            return;
        }
        throw std::runtime_error(A6_STATUS_TEXT("vm syscall ")+std::to_string(nr));
    }
    // A6 SDK | @a6wzneihe
    static void A6C_interrupt(uc_engine*,uint32_t number,void* value){
        auto& m=*static_cast<A6CMachine*>(value);try{if(number!=2)throw std::runtime_error(A6_STATUS_TEXT("vm interrupt ")+std::to_string(number));m.A6C_syscall();}
        catch(const std::exception& e){m.A6C_fail(e.what());}
    }
    // A6 SDK | @a6wzneihe
    void A6C_openEngine() {
        A6C_check(uc_open(UC_ARCH_ARM64,UC_MODE_ARM,&cpu));
        try {A6C_map(scratch,0x20000);
        uc_hook h;A6C_check(uc_hook_add(cpu,&h,UC_HOOK_MEM_UNMAPPED,(void*)A6C_missing,this,1,0));
        A6C_check(uc_hook_add(cpu,&h,UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,(void*)A6C_access,this,1,0));
        A6C_check(uc_hook_add(cpu,&h,UC_HOOK_CODE,(void*)A6C_code,this,1,0));
        A6C_check(uc_hook_add(cpu,&h,UC_HOOK_INTR,(void*)A6C_interrupt,this,1,0));
        }catch(...){uc_close(cpu);cpu=nullptr;throw;}
    }
public:
    // A6 SDK | @a6wzneihe
    explicit A6CMachine(std::function<bool(U,void*,std::size_t)> read,int pid=0,std::function<bool(U)> execute={}):source(std::move(read)),target(pid),executableAddress(std::move(execute)) {
        A6C_openEngine();
    }
    // A6 SDK | @a6wzneihe
    ~A6CMachine(){if(cpu)uc_close(cpu);}
    A6CMachine(const A6CMachine&)=delete;
    // A6 SDK | @a6wzneihe
    void A6C_bindSymbols(const std::map<U,unsigned>& values){symbols.clear();for(auto [pc,kind]:values)if(kind<9)symbols[pc]=kind;}
    // A6 SDK | @a6wzneihe
    void A6C_setSignal(U value,std::function<bool(U)> allowed){signalHandler=value;signalAddress=std::move(allowed);}
    // A6 SDK | @a6wzneihe
    void A6C_provide(U address,const void* bytes,std::size_t size){A6C_output(address,bytes,size);}
    // A6 SDK | @a6wzneihe
    void A6C_freshData(){
        // Retained Unicorn mappings have execution state as well as bytes.
        // Preserve normal reuse, then recycle the complete private engine at
        // the existing page ceiling. A single oversized execution still fails.
        if(pages.size()>=512){
            if(cpu)uc_close(cpu);cpu=nullptr;
            pages.clear();codePages.clear();loaded.clear();written.clear();
            A6C_openEngine();
        }
        loaded.clear();written.clear();tls.clear();syncId=1;pendingFault=0;insideSignal=false;
        static const std::array<unsigned char,0x20000> zero{};
        A6C_check(uc_mem_write(cpu,scratch,zero.data(),zero.size()));
        for(unsigned i=0;i<31;++i)A6C_reg(i<29?UC_ARM64_REG_X0+i:i==29?UC_ARM64_REG_X29:UC_ARM64_REG_X30,0);
        A6C_reg(UC_ARM64_REG_NZCV,0);
    }
    // A6 SDK | @a6wzneihe
    unsigned A6C_changedInputs() {
        unsigned changed=0;
        for(auto it=loaded.begin();it!=loaded.end();){
            U start=it->first;std::vector<unsigned char> expected;
            while(it!=loaded.end()&&it->first==start+expected.size()&&expected.size()<128){expected.push_back(it->second);++it;}
            std::vector<unsigned char> actual(expected.size());
            if(!source(start,actual.data(),actual.size())||actual!=expected)++changed;
        }
        return changed;
    }
    // A6 SDK | @a6wzneihe
    U A6C_reg(int r){U v=0;A6C_check(uc_reg_read(cpu,r,&v));return v;}
    // A6 SDK | @a6wzneihe
    void A6C_reg(int r,U v){A6C_check(uc_reg_write(cpu,r,&v));}
    // A6 SDK | @a6wzneihe
    U A6C_run(U entry,U x0,U x1=0,U x2=0,U x3=0){
        steps=0;deadline=A6C_clock()+30000;failed.clear();
        A6C_reg(UC_ARM64_REG_SP,scratch+0x1e000);A6C_reg(UC_ARM64_REG_LR,stop);
        A6C_reg(UC_ARM64_REG_X0,x0);A6C_reg(UC_ARM64_REG_X1,x1);A6C_reg(UC_ARM64_REG_X2,x2);
        A6C_reg(UC_ARM64_REG_X3,x3);
        U begin=entry;
        for(unsigned signals=0;;){
            pendingFault=0;auto e=uc_emu_start(cpu,begin,stop,0,50000-std::min(steps,49999u));
            if(!failed.empty())throw std::runtime_error(failed);
            if(!pendingFault){A6C_check(e);break;}
            if(++signals>4)throw std::runtime_error(A6_STATUS_TEXT("vm signal budget"));
            const U frameAddress=scratch+0x18000,infoAddress=scratch+0x17000,signalReturn=scratch+0x1f100;
            std::array<unsigned char,4096> frame{};std::array<unsigned char,128> info{};
            auto put=[](auto& data,std::size_t offset,U value){std::memcpy(data.data()+offset,&value,8);};
            put(frame,0xb0,pendingFault);put(info,0,11);put(info,8,2);put(info,16,pendingFault);
            for(unsigned i=0;i<31;++i)put(frame,0xb8+i*8,A6C_reg(i<29?UC_ARM64_REG_X0+i:i==29?UC_ARM64_REG_X29:UC_ARM64_REG_X30));
            put(frame,0x1b0,A6C_reg(UC_ARM64_REG_SP));put(frame,0x1b8,A6C_reg(UC_ARM64_REG_PC));put(frame,0x1c0,A6C_reg(UC_ARM64_REG_NZCV));
            uc_context* saved=nullptr;A6C_check(uc_context_alloc(cpu,&saved));A6C_check(uc_context_save(cpu,saved));
            A6C_output(frameAddress,frame.data(),frame.size());A6C_output(infoAddress,info.data(),info.size());
            A6C_reg(UC_ARM64_REG_X0,11);A6C_reg(UC_ARM64_REG_X1,infoAddress);A6C_reg(UC_ARM64_REG_X2,frameAddress);
            A6C_reg(UC_ARM64_REG_SP,scratch+0x16000);A6C_reg(UC_ARM64_REG_LR,signalReturn);
            insideSignal=true;e=uc_emu_start(cpu,signalHandler,signalReturn,0,50000-std::min(steps,49999u));insideSignal=false;
            if(!failed.empty()){uc_context_free(saved);throw std::runtime_error(failed);}
            if(e!=UC_ERR_OK||A6C_reg(UC_ARM64_REG_PC)!=signalReturn){uc_context_free(saved);throw std::runtime_error(A6_STATUS_TEXT("vm signal incomplete"));}
            std::array<unsigned char,4096> after{};A6C_check(uc_mem_read(cpu,frameAddress,after.data(),after.size()));
            A6C_check(uc_context_restore(cpu,saved));uc_context_free(saved);
            if(!std::equal(frame.begin(),frame.begin()+0xb8,after.begin())||!std::equal(frame.begin()+0x1c8,frame.end(),after.begin()+0x1c8))throw std::runtime_error(A6_STATUS_TEXT("vm signal frame"));
            auto get=[&](std::size_t offset){U value=0;std::memcpy(&value,after.data()+offset,8);return value;};
            for(unsigned i=0;i<31;++i)A6C_reg(i<29?UC_ARM64_REG_X0+i:i==29?UC_ARM64_REG_X29:UC_ARM64_REG_X30,get(0xb8+i*8));
            A6C_reg(UC_ARM64_REG_SP,get(0x1b0));A6C_reg(UC_ARM64_REG_PC,get(0x1b8));A6C_reg(UC_ARM64_REG_NZCV,get(0x1c0)&0xf0000000);
            begin=get(0x1b8);
        }
        if(A6C_reg(UC_ARM64_REG_PC)!=stop)throw std::runtime_error(A6_STATUS_TEXT("vm incomplete"));
        return A6C_reg(UC_ARM64_REG_X0);
    }
    // A6 SDK | @a6wzneihe
    void A6C_read(U a,void* out,std::size_t n){for(std::size_t i=0;i<n;i+=128)A6C_input(a+i,std::min<std::size_t>(128,n-i));A6C_check(uc_mem_read(cpu,a,out,n));}
    // A6 SDK | @a6wzneihe
    unsigned A6C_instructions()const{return steps;}
};
}
