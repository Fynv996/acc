// A6 C SDK | immutable host-supplied inputs | @a6wzneihe
#pragma once
#include "A6C.h"
#include "internal/A6C_Types.hpp"
namespace A6CInput {
struct A6CGuard {
    std::uint64_t address=0;
    A6CInternal::Bytes expected;
};
struct A6CBinding {
    int pid=0;
    std::uint64_t start_ticks=0,epoch=0,access_slot=0,publish_slot=0;
    std::array<A6C_Target,A6C_MAX_POINTS> targets{};
    std::vector<A6CGuard> guards;
};
// A6 | @a6wzneihe: validate and own all callback-lifetime-independent data.
std::shared_ptr<const A6CBinding> A6C_CopyBinding(const A6C_Binding& source);
// A6 | @a6wzneihe: exact equality keeps repeated binding calls inexpensive.
bool A6C_SameBinding(const A6CBinding& left,const A6CBinding& right) noexcept;
// A6 | @a6wzneihe: a caller must not reuse an epoch for changed input.
bool A6C_EpochConflict(const A6CBinding& left,const A6CBinding& right) noexcept;
}
