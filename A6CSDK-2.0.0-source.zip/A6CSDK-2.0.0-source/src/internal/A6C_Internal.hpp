// A6 C SDK | private host adapters | @a6wzneihe
#pragma once
#include "A6C.h"
#include "internal/A6C_Types.hpp"
#include "internal/A6C_Binding.hpp"
namespace A6CAdapter {
std::shared_ptr<A6CInternal::A6CBackend> A6C_MakeBackend(const A6C_Config& config);
}
