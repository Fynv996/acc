// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include "internal/A6C_Status.hpp"
#include <elf.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <stdexcept>

namespace A6CExecution {
// Symbols belong to the exact currently executable libc inode. Read-only
// aliases of that file do not determine its load bias.
// A6 SDK | @a6wzneihe
inline std::map<std::uint64_t,unsigned> A6C_imports(int pid) {
    using U=std::uint64_t;
    struct A6CMap {U begin,end,offset,inode;unsigned major,minor;std::string path;};
    std::vector<A6CMap> executable;
    std::ifstream stream("/proc/"+std::to_string(pid)+"/maps");std::string line;
    while(std::getline(stream,line)) {
        unsigned long long begin,end,offset,inode;unsigned major,minor;char permissions[8]{};int used=0;
        if(std::sscanf(line.c_str(),"%llx-%llx %7s %llx %x:%x %llu %n",&begin,&end,permissions,&offset,&major,&minor,&inode,&used)!=7)continue;
        std::string path=line.substr(used);
        if(permissions[2]=='x'&&path.size()>8&&path.compare(path.size()-8,8,"/libc.so")==0)
            executable.push_back({begin,end,offset,inode,major,minor,std::move(path)});
    }
    if(executable.empty())throw std::runtime_error(A6_STATUS_TEXT("C runtime image absent"));
    const auto& image=executable.front();
    struct A6CFile {int fd=-1;~A6CFile(){if(fd>=0)close(fd);}} file;
    file.fd=open(("/proc/"+std::to_string(pid)+"/root"+image.path).c_str(),O_RDONLY|O_CLOEXEC);
    struct stat stat{};
    if(file.fd<0||fstat(file.fd,&stat)||!S_ISREG(stat.st_mode)||U(stat.st_ino)!=image.inode||
       major(stat.st_dev)!=image.major||minor(stat.st_dev)!=image.minor)
        throw std::runtime_error(A6_STATUS_TEXT("C runtime inode changed"));
    auto read=[&](U at,void* out,std::size_t size){
        if(at>U(stat.st_size)||size>U(stat.st_size)-at||size>1048576||
           pread(file.fd,out,size,static_cast<off_t>(at))!=static_cast<ssize_t>(size))
            throw std::runtime_error(A6_STATUS_TEXT("C runtime metadata unavailable"));
    };
    Elf64_Ehdr h{};read(0,&h,sizeof(h));
    if(std::memcmp(h.e_ident,ELFMAG,4)||h.e_ident[EI_CLASS]!=ELFCLASS64||h.e_ident[EI_DATA]!=ELFDATA2LSB||
       h.e_machine!=EM_AARCH64||h.e_type!=ET_DYN||!h.e_phnum||h.e_phnum>128||
       h.e_phentsize!=sizeof(Elf64_Phdr)||h.e_shnum>512||h.e_shentsize!=sizeof(Elf64_Shdr))
        throw std::runtime_error(A6_STATUS_TEXT("C runtime metadata contract"));
    std::vector<Elf64_Phdr> ph(h.e_phnum);read(h.e_phoff,ph.data(),ph.size()*sizeof(ph[0]));
    std::set<U> bases;
    for(const auto& map:executable) {
        if(map.inode!=image.inode||map.major!=image.major||map.minor!=image.minor||map.path!=image.path)
            throw std::runtime_error(A6_STATUS_TEXT("C runtime aliases differ"));
        for(const auto& segment:ph)if(segment.p_type==PT_LOAD&&(segment.p_flags&PF_X)&&
            map.offset>=segment.p_offset&&map.offset-segment.p_offset<segment.p_filesz) {
            U relative=segment.p_vaddr+map.offset-segment.p_offset;
            if(map.begin>=relative)bases.insert(map.begin-relative);
        }
    }
    if(bases.size()!=1)throw std::runtime_error(A6_STATUS_TEXT("C runtime base ambiguous"));
    const U base=*bases.begin();
    std::vector<Elf64_Shdr> sections(h.e_shnum);read(h.e_shoff,sections.data(),sections.size()*sizeof(sections[0]));
    const std::map<std::string,unsigned> wanted{{"pthread_getspecific",0},{"pthread_setspecific",1},{"ioctl",2},
        {"memcpy",3},{"memmove",4},{"memset",5},{"memcmp",6},{"strlen",7},{"__errno",8}};
    std::map<U,unsigned> result;
    for(const auto& section:sections)if(section.sh_type==SHT_DYNSYM) {
        if(section.sh_link>=sections.size()||section.sh_entsize!=sizeof(Elf64_Sym)||section.sh_size%sizeof(Elf64_Sym))
            throw std::runtime_error(A6_STATUS_TEXT("C runtime symbol contract"));
        const auto& strings=sections[section.sh_link];
        std::vector<char> names(strings.sh_size);read(strings.sh_offset,names.data(),names.size());
        std::vector<Elf64_Sym> symbols(section.sh_size/sizeof(Elf64_Sym));read(section.sh_offset,symbols.data(),section.sh_size);
        for(const auto& symbol:symbols) {
            if(symbol.st_shndx==SHN_UNDEF||!symbol.st_value||symbol.st_name>=names.size())continue;
            const char* name=names.data()+symbol.st_name;
            if(!std::memchr(name,0,std::min<std::size_t>(256,names.size()-symbol.st_name)))continue;
            auto found=wanted.find(name);if(found==wanted.end())continue;
            const U address=base+symbol.st_value;
            bool mapped=false;for(const auto& m:executable)mapped|=address>=m.begin&&address<m.end;
            if(!mapped)throw std::runtime_error(A6_STATUS_TEXT("C runtime symbol not executable"));
            result.emplace(address,found->second);
        }
    }
    if(result.size()!=wanted.size())throw std::runtime_error(A6_STATUS_TEXT("C runtime symbols incomplete"));
    return result;
}
}
