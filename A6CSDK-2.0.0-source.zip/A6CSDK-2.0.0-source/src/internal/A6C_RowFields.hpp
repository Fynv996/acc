// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include "internal/A6C_Analysis.hpp"
namespace A6CInternal::detail {
inline std::pair<std::set<U>, std::set<U>> A6C_row_field_offsets(
    const A6CGraph &graph, U start, U decoder, const A6CDisassembler &cs) {
    using Origin = std::pair<bool, U>; // false: row address; true: loaded value
    using Registers = std::map<std::string, Origin>;
    using Work = std::pair<U, Registers>;
    std::vector<Work> todo;
    std::set<Work> seen;
    std::set<U> objects, ciphers;
    auto enqueue = [&](U a, const Registers &values) {
        auto edge = graph.edges.find(a);
        if (edge != graph.edges.end())
            for (U target : edge->second) todo.emplace_back(target, values);
    };
    enqueue(start, {{cs.A6C_norm(graph.instructions.at(start).A6C_op(0).reg), {false, 0}}});
    while (!todo.empty()) {
        Work work = std::move(todo.back());
        todo.pop_back();
        if (!seen.insert(work).second) continue;
        A6C_require(seen.size() <= 4096, "");
        auto at = graph.instructions.find(work.first);
        if (at == graph.instructions.end()) continue;
        const auto &i = at->second;
        auto &values = work.second;
        if (i.name == "madd" || i.name == "ret") continue;
        if (i.name == "bl" || i.name == "blr") {
            auto value = values.find("x0");
            if (i.name == "bl" && U(i.A6C_op(0).imm) == decoder &&
                value != values.end() && value->second.first)
                ciphers.insert(value->second.second);
            continue;
        }
        if (i.name == "eor" && i.a.op_count == 3) {
            for (unsigned k : {1u, 2u}) {
                const auto &source = i.A6C_op(k), &other = i.A6C_op(3 - k);
                if (source.type != ARM64_OP_REG || other.type != ARM64_OP_REG ||
                    cs.A6C_norm(other.reg) != "x0") continue;
                auto value = values.find(cs.A6C_norm(source.reg));
                if (value != values.end() && value->second.first)
                    objects.insert(value->second.second);
            }
        }
        bool produced = false;
        Origin result{};
        if (i.name == "add" && i.a.op_count == 3 && i.A6C_op(2).type == ARM64_OP_IMM &&
            A6C_starts(cs.A6C_reg(i.A6C_op(0).reg), "x")) {
            auto source = values.find(cs.A6C_norm(i.A6C_op(1).reg));
            if (source != values.end() && !source->second.first) {
                result = {false, source->second.second + (U(i.A6C_op(2).imm) << i.A6C_op(2).shift.value)};
                produced = true;
            }
        } else if (i.name == "mov" && i.a.op_count == 2 && i.A6C_op(1).type == ARM64_OP_REG &&
                   A6C_starts(cs.A6C_reg(i.A6C_op(0).reg), "x")) {
            auto source = values.find(cs.A6C_norm(i.A6C_op(1).reg));
            if (source != values.end()) { result = source->second; produced = true; }
        } else if (i.name == "ldr" && i.a.op_count == 2 && i.A6C_op(1).type == ARM64_OP_MEM &&
                   !i.A6C_op(1).mem.index && !i.a.writeback && A6C_starts(cs.A6C_reg(i.A6C_op(0).reg), "x")) {
            auto source = values.find(cs.A6C_norm(i.A6C_op(1).mem.base));
            if (source != values.end() && !source->second.first) {
                result = {true, source->second.second + i.A6C_op(1).mem.disp};
                produced = true;
            }
        }
        for (unsigned reg : i.writes) values.erase(cs.A6C_norm(reg));
        if (produced) values[cs.A6C_norm(i.A6C_op(0).reg)] = result;
        if (!values.empty()) enqueue(i.address, values);
    }
    return {objects, ciphers};
}
}
