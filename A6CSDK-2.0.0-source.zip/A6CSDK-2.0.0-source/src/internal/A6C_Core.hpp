// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#pragma once
#include "internal/A6C_Types.hpp"
#include "internal/A6C_Binding.hpp"

namespace A6CCore {
// Independent C route. Executable bytes and data are copied into a local
// machine; the backend exposes no target write or execution operation.
class A6CReader {
public:
    explicit A6CReader(std::shared_ptr<A6CInternal::A6CBackend> backend);
    ~A6CReader();
    A6CReader(const A6CReader&)=delete;
    A6CReader& operator=(const A6CReader&)=delete;
    A6CInternal::A6CFrame A6C_poll(std::shared_ptr<const A6CInput::A6CBinding> binding);
    void A6C_reset();
private:
    struct A6CImpl;
    std::unique_ptr<A6CImpl> impl_;
};
}
