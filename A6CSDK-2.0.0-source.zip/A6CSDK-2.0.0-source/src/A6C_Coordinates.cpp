// A6 C SDK | A6-owned implementation | Channel: @a6wzneihe
#include "internal/A6C_Core.hpp"
#include "internal/A6C_Execution.hpp"
#include "internal/A6C_Imports.hpp"
#include "internal/A6C_Sandbox.hpp"
#include "internal/A6C_RowFields.hpp"
#include <algorithm>
#include <array>
#include <map>
#include <set>
#include <deque>

namespace A6CCore {
namespace {
namespace d=A6CInternal::detail;
using U=std::uint64_t;
using Bytes=A6CInternal::Bytes;
constexpr U mask=0x00ffffffffffffffULL;
using Retry=A6CStatus::A6CFault<A6CInternal::A6CReasonCode,A6CInternal::A6CReasonCode::other>;
using Unsupported=A6CStatus::A6CError<41,Retry>;
using ReadFailure=A6CStatus::A6CError<42,Retry>;
using BindingChanged=A6CStatus::A6CError<43,Retry>;
// A6 SDK | @a6wzneihe
void A6C_require(bool value,const char* why){if(!value)throw Unsupported(why);}
// A6 SDK | @a6wzneihe
void A6C_ready(bool value,const char* why){if(!value)throw Retry(why);}
// A6 SDK | @a6wzneihe
bool A6C_scalar(const d::A6CValue& value,U& out){if(value.kind!=d::A6CValue::constants||value.values.size()!=1)return false;out=*value.values.begin();return true;}
template<class T>T A6C_number(const Bytes& data,std::size_t offset=0){T value{};A6C_require(offset<=data.size()&&sizeof(value)<=data.size()-offset,A6_STATUS_TEXT("C short value"));std::memcpy(&value,data.data()+offset,sizeof(value));return value;}
struct A6CCall {U pc=0,fn=0;std::array<U,4> args{};unsigned known=0;};
struct A6CTarget {U actor=0,owner=0;std::uint32_t key=0,camp=0;};
// A6 SDK | @a6wzneihe
bool A6C_valid(const std::array<U,35>& words){
    for(unsigned row=0;row<5;++row){
        const U flags=words[row*7+6];if(!(flags&1)||flags>63)return false;
        for(unsigned col=0;col<6;++col){const U v=words[row*7+col];if(!(flags&(U(1)<<col))){if(v)return false;continue;}
            if(std::abs(std::int64_t(std::int32_t(v)))>1000000||std::abs(std::int64_t(std::int32_t(v>>32)))>1000000)return false;}
    }
    return true;
}
}

struct A6CReader::A6CImpl {
    std::shared_ptr<A6CInternal::A6CBackend> backend;
    std::shared_ptr<const A6CInput::A6CBinding> binding;
    int pid=0;U start=0,generation=1,sequence=0,bytes=0,budget=0;
    U entry=0,producer=0,origin=0,stride=0,count=0,bank=0,phase=0,plainSlot=0,plainFunction=0;
    unsigned displacement=0,failures=0;U retryAt=0,checkAt=0;
    A6CInternal::A6CFrame waitingFrame{};
    bool complete=false,direct=false;
    A6CCall decode{};
    std::vector<U> ownerFields,gateFlags,handlers;
    std::vector<A6CInternal::A6CMapping> maps;
    std::map<U,Bytes> guards,code;
    std::map<U,U> branches;
    std::unique_ptr<A6CExecution::A6CMachine> machine;
    // A6 SDK | @a6wzneihe
    explicit A6CImpl(std::shared_ptr<A6CInternal::A6CBackend> value):backend(std::move(value)){}
    // A6 SDK | @a6wzneihe
    void A6C_drop(){complete=direct=false;entry=producer=origin=stride=count=bank=phase=plainSlot=plainFunction=0;displacement=0;ownerFields.clear();gateFlags.clear();handlers.clear();code.clear();branches.clear();machine.reset();checkAt=0;waitingFrame={};++generation;}
    // A6 SDK | @a6wzneihe
    void A6C_reset(){A6C_drop();binding.reset();maps.clear();pid=0;start=0;failures=0;retryAt=0;guards.clear();}
    // A6 SDK | @a6wzneihe
    bool A6C_mapped(U at,std::size_t size,char permission='r')const{
        if(!size||at<0x10000||at>mask-size)return false;
        auto it=std::upper_bound(maps.begin(),maps.end(),at,[](U a,const auto& m){return a<m.start;});
        if(it==maps.begin())return false;--it;
        return at>=it->start&&at<it->end&&size<=it->end-at&&it->permissions.find(permission)!=std::string::npos;
    }
    // A6 SDK | @a6wzneihe
    bool A6C_fault(U at)const{
        at&=mask;
        for(const auto& m:maps)if(at>=m.start&&at<m.end)return m.permissions.find('r')==std::string::npos;
        return false;
    }
    // A6 SDK | @a6wzneihe
    bool A6C_raw(U at,void* out,std::size_t size){
        at&=mask;
        if(!size||size>4096||bytes>budget||size>budget-bytes||!A6C_mapped(at,size))return false;
        bytes+=size;return backend->A6C_read(pid,at,out,size);
    }
    // A6 SDK | @a6wzneihe
    Bytes A6C_read(U at,std::size_t size,bool track=false){
        at&=mask;Bytes result(size);
        if(!A6C_raw(at,result.data(),size))throw ReadFailure(A6_STATUS_TEXT("C exact read failed"));
        if(track){auto [it,inserted]=guards.emplace(at,result);A6C_ready(inserted||it->second==result,A6_STATUS_TEXT("C input changed"));}
        return result;
    }
    template<class T>T A6C_get(U at,bool track=false){return A6C_number<T>(A6C_read(at,sizeof(T),track));}
    // A6 SDK | @a6wzneihe
    U A6C_ptr(U at,bool track=false){return A6C_get<U>(at,track)&mask;}
    // A6 SDK | @a6wzneihe
    void A6C_checkBinding(){
        const auto identity=backend->A6C_identity(pid,pid);
        if(!binding||identity.tid!=pid||identity.start_ticks!=start)
            throw BindingChanged(A6_STATUS_TEXT("C input identity changed"));
        for(const auto& guard:binding->guards)
            if(A6C_read(guard.address,guard.expected.size(),true)!=guard.expected)
                throw BindingChanged(A6_STATUS_TEXT("C input guard changed"));
    }
    // A6 SDK | @a6wzneihe
    d::Read A6C_reader(){return [this](U a,std::size_t n,const std::string&){return A6C_read(a,n);};}
    // A6 SDK | @a6wzneihe
    void A6C_validate(const std::map<U,Bytes>& snapshot){A6C_checkBinding();for(const auto& [a,value]:snapshot)A6C_ready(A6C_read(a,value.size())==value,A6_STATUS_TEXT("C binding changed"));}
    // A6 SDK | @a6wzneihe
    void A6C_validate(){A6C_validate(guards);}
    // A6 SDK | @a6wzneihe
    void A6C_bind(std::shared_ptr<const A6CInput::A6CBinding> active){
        A6C_reset();binding=std::move(active);
        A6C_require(bool(binding),A6_STATUS_TEXT("C input absent"));pid=binding->pid;start=binding->start_ticks;
        const auto identity=backend->A6C_identity(pid,pid);
        if(identity.tid!=pid||identity.start_ticks!=start)
            throw BindingChanged(A6_STATUS_TEXT("C input process replaced"));
        maps=backend->A6C_maps(pid);std::sort(maps.begin(),maps.end(),[](const auto& a,const auto& b){return a.start<b.start;});
        A6C_require(!maps.empty(),A6_STATUS_TEXT("C input maps absent"));
        A6C_checkBinding();
    }
    // A6 SDK | @a6wzneihe
    std::array<A6CTarget,5> A6C_targets(){
        A6C_checkBinding();std::array<A6CTarget,5> result{};
        for(unsigned i=0;i<result.size();++i){
            const auto& source=binding->targets[i];
            A6C_ready(A6C_mapped(source.actor_address,8)&&A6C_mapped(source.object_address,8),A6_STATUS_TEXT("C bound object unavailable"));
            result[i]={source.actor_address,source.object_address,source.actor_key,source.camp};
        }
        return result;
    }
    // A6 SDK | @a6wzneihe
    bool A6C_original(U function,unsigned& at){
        d::A6CDisassembler cs;auto b=A6C_read(function,8);
        auto l=cs.A6C_decode(Bytes(b.begin(),b.begin()+4),function),r=cs.A6C_decode(Bytes(b.begin()+4,b.end()),function+4);
        if(l.name!="ldr"||r.name!="ret"||l.a.op_count!=2||l.A6C_op(1).type!=ARM64_OP_MEM||
           cs.A6C_norm(l.A6C_op(0).reg)!="x0"||cs.A6C_norm(l.A6C_op(1).mem.base)!="x0"||l.A6C_op(1).mem.index||l.A6C_op(1).mem.disp<0||l.A6C_op(1).mem.disp>=512)return false;
        at=unsigned(l.A6C_op(1).mem.disp);return true;
    }
    // A6 SDK | @a6wzneihe
    void A6C_remember(const d::A6CGraph& graph){for(const auto& [pc,i]:graph.instructions)code[pc]=Bytes(i.bytes.begin(),i.bytes.end());branches.insert(graph.words.begin(),graph.words.end());}
    // A6 SDK | @a6wzneihe
    void A6C_discover(){
        ownerFields.clear();gateFlags.clear();handlers.clear();code.clear();branches.clear();machine.reset();
        count=origin=stride=bank=phase=plainSlot=plainFunction=0;
        if(A6C_original(entry,displacement)){plainFunction=entry;direct=complete=true;return;}
        d::A6CReferenceGraph graph(A6C_reader(),0x10000,mask,4000);graph.widen_boolean_loads=true;graph.widen_shifted_unknowns=true;
        auto wrapper=graph.A6C_walk(entry);A6C_remember(wrapper);std::set<U> calls;
        for(U fn:wrapper.A6C_calls())calls.insert(fn);A6C_require(calls.size()==1,A6_STATUS_TEXT("C getter call not unique"));
        for(const auto& [pc,i]:wrapper.instructions){
            if((i.name=="ldrb"||i.name=="ldurb")&&i.A6C_op(1).type==ARM64_OP_MEM){U a=0;if(A6C_scalar(graph.A6C_address(i.A6C_op(1),wrapper.states.at(pc)),a))gateFlags.push_back(a);}
            if(i.name=="br"&&i.a.op_count==1){const auto v=wrapper.states.at(pc).A6C_get(graph.cs.A6C_norm(i.A6C_op(0).reg));if(v.kind==d::A6CValue::load&&!v.indexed&&v.size==8&&v.values.size()==1)plainSlot=*v.values.begin();}
        }
        std::sort(gateFlags.begin(),gateFlags.end());gateFlags.erase(std::unique(gateFlags.begin(),gateFlags.end()),gateFlags.end());
        A6C_require(gateFlags.size()==2&&plainSlot,A6_STATUS_TEXT("C representation gate ambiguous"));
        plainFunction=A6C_ptr(plainSlot,true);A6C_require(A6C_original(plainFunction,displacement),A6_STATUS_TEXT("C original accessor changed"));
        const U resolver=*calls.begin();auto rows=graph.A6C_walk(resolver);A6C_remember(rows);
        std::set<std::pair<U,U>> shapes;std::set<U> fields;
        for(const auto& [pc,i]:rows.instructions){
            if(i.name=="madd"&&i.a.op_count==4){U s=0,a=0;
                if(A6C_scalar(graph.A6C_operand(i,i.A6C_op(2),rows.states.at(pc)),s)&&A6C_scalar(graph.A6C_operand(i,i.A6C_op(3),rows.states.at(pc)),a)&&s>=24&&s<=4096&&a>=0x10000){
                    shapes.emplace(a,s);for(U fn:rows.A6C_calls()){auto f=d::A6C_row_field_offsets(rows,pc,fn,graph.cs);fields.insert(f.first.begin(),f.first.end());}
                }
            }
            if(i.name=="ldr"&&i.a.op_count>=2&&graph.cs.A6C_reg(i.A6C_op(0).reg).front()=='w'&&i.A6C_op(1).type==ARM64_OP_MEM){U a=0;if(A6C_scalar(graph.A6C_address(i.A6C_op(1),rows.states.at(pc)),a)&&!count)count=a;}
        }
        A6C_require(shapes.size()==1&&!fields.empty()&&fields.size()<=4&&count,A6_STATUS_TEXT("C roster table ambiguous"));
        origin=shapes.begin()->first;stride=shapes.begin()->second;
        for(U field:fields){
            A6C_require(field<=4096-8&&!(field&7),A6_STATUS_TEXT("C owner field invalid"));
            d::A6CSandbox vm(code,branches,A6C_reader());vm.A6C_poke(count,d::A6C_raw(1,4));
            for(const auto& [pc,i]:rows.instructions)if(i.name=="ldrb"&&i.A6C_op(1).type==ARM64_OP_MEM){U a=0;if(A6C_scalar(graph.A6C_address(i.A6C_op(1),rows.states.at(pc)),a))vm.A6C_poke(a,d::A6C_raw(1,1));}
            constexpr U token=0x1234567800ULL;
            for(U other:fields)vm.A6C_poke(origin+other,d::A6C_raw(other==field?token:token+256));
            unsigned used=0;for(U fn:rows.A6C_calls())vm.A6C_stub(fn,[&](auto& local){++used;local.A6C_reg(UC_ARM64_REG_X0,token);});
            vm.A6C_run(resolver,token,0,4000);A6C_require(used==1,A6_STATUS_TEXT("C owner relation unproved"));ownerFields.push_back(field);
        }
        producer=A6C_ptr(binding->publish_slot,true);auto publication=graph.A6C_walk(producer);A6C_remember(publication);
        std::vector<A6CCall> production;std::map<U,unsigned> flags;
        for(const auto& [pc,i]:publication.instructions){
            if(i.name=="bl"){
                A6CCall c;c.pc=pc;c.fn=U(i.A6C_op(0).imm);
                for(unsigned n=0;n<4;++n)if(A6C_scalar(publication.states.at(pc).A6C_get("x"+std::to_string(n)),c.args[n]))c.known|=1u<<n;
                if((c.known&3)==3)production.push_back(c);
            }
            if(i.name=="strb"&&i.A6C_op(1).type==ARM64_OP_MEM){U a=0,v=0;if(A6C_scalar(graph.A6C_address(i.A6C_op(1),publication.states.at(pc)),a)&&A6C_scalar(graph.A6C_operand(i,i.A6C_op(0),publication.states.at(pc)),v)&&v<=1)flags[a]|=1u<<v;}
        }
        std::set<U> phases;for(auto [a,bits]:flags)if(bits==3)phases.insert(a);A6C_require(phases.size()==1,A6_STATUS_TEXT("C publication phase ambiguous"));phase=*phases.begin();
        std::set<std::pair<U,U>> banks;
        // Restoring at least the first three indexed rows proves base and stride.
        for(const auto& c:production)if(c.args[0]==0&&c.args[1]>=0x10000){
            std::map<U,U> indexed;for(const auto& o:production)if(o.fn==c.fn&&o.args[0]<5)indexed[o.args[0]]=o.args[1];
            if(!indexed.count(1)||!indexed.count(2)||indexed[1]<=c.args[1])continue;
            const U step=indexed[1]-c.args[1];if(step!=56)continue;
            bool good=true;for(auto [i,address]:indexed)good&=address==c.args[1]+i*step;if(good)banks.emplace(c.args[1],step);
        }
        A6C_require(banks.size()==1,A6_STATUS_TEXT("C saved rows ambiguous"));bank=banks.begin()->first;
        std::vector<A6CCall> decoders;
        for(const auto& c:production)if(c.known==15&&c.args[0]==bank&&c.args[1]==280){
            for(auto it=publication.instructions.upper_bound(c.pc);it!=publication.instructions.end()&&it->first<c.pc+128;++it){
                const auto& i=it->second;if(i.name=="bl"||i.name=="ret")break;
                if(i.name=="strb"&&i.A6C_op(1).type==ARM64_OP_MEM){U a=0,v=0;if(A6C_scalar(graph.A6C_address(i.A6C_op(1),publication.states.at(it->first)),a)&&a==phase&&A6C_scalar(graph.A6C_operand(i,i.A6C_op(0),publication.states.at(it->first)),v)){if(v==0)decoders.push_back(c);break;}}
            }
        }
        A6C_require(decoders.size()==1,A6_STATUS_TEXT("C restore call ambiguous"));decode=decoders.front();
        A6C_require(decode.args[2]>=0x10000&&decode.args[3]<=1,A6_STATUS_TEXT("C restore arguments invalid"));
        // Discover only the active protection image. Do not scan heap mappings.
        auto range=std::find_if(maps.begin(),maps.end(),[&](const auto& m){return m.start<=entry&&entry<m.end&&m.permissions.find('x')!=std::string::npos;});
        A6C_require(range!=maps.end()&&range->end-range->start<=524288,A6_STATUS_TEXT("C protection image bounds"));
        Bytes image(range->end-range->start);std::vector<bool> available(image.size(),false);
        for(U at=range->start;at<range->end;at+=4096){
            for(U chunk=at;chunk<std::min(at+4096,range->end);chunk+=256){
                const auto size=std::size_t(std::min<U>(256,range->end-chunk));
                if(!A6C_raw(chunk,image.data()+chunk-range->start,size))break;
                std::fill(available.begin()+chunk-range->start,available.begin()+chunk-range->start+size,true);
            }
        }
        d::A6CDisassembler cs;std::set<U> candidates;
        for(std::size_t at=0;at+24<image.size();at+=4){
            const auto word=A6C_number<std::uint32_t>(image,at);if(word!=0x52800160&&word!=0xd2800160)continue;
            std::vector<d::A6CInstruction> window;const auto begin=at>=64?at-64:0;
            if(!std::all_of(available.begin()+begin,available.begin()+at+20,[](bool value){return value;}))continue;
            for(auto j=begin;j<at+20;j+=4)window.push_back(cs.A6C_decode(Bytes(image.begin()+j,image.begin()+j+4),range->start+j));
            for(const auto& adr:window)if(adr.name=="adr"&&adr.a.op_count==2&&adr.A6C_op(1).type==ARM64_OP_IMM){
                for(const auto& store:window)if(store.name=="str"&&store.a.op_count==2&&store.A6C_op(0).type==ARM64_OP_REG&&store.A6C_op(0).reg==adr.A6C_op(0).reg&&store.A6C_op(1).type==ARM64_OP_MEM&&cs.A6C_norm(store.A6C_op(1).mem.base)=="sp"){
                    for(const auto& arg:window)if(arg.name=="add"&&arg.a.op_count==3&&cs.A6C_norm(arg.A6C_op(0).reg)=="x1"&&cs.A6C_norm(arg.A6C_op(1).reg)=="sp"&&arg.A6C_op(2).type==ARM64_OP_IMM&&arg.A6C_op(2).imm+8==store.A6C_op(1).mem.disp){
                        const U handler=U(adr.A6C_op(1).imm);if(A6C_mapped(handler,4,'x'))candidates.insert(handler);
                    }
                }
            }
        }
        A6C_require(!candidates.empty()&&candidates.size()<=4,A6_STATUS_TEXT("C signal registration ambiguous"));handlers.assign(candidates.begin(),candidates.end());
        machine=std::make_unique<A6CExecution::A6CMachine>([this](U a,void* out,std::size_t n){return A6C_raw(a,out,n);},pid,[this](U a){return A6C_mapped(a,4,'x');});
        machine->A6C_bindSymbols(A6CExecution::A6C_imports(pid));complete=true;checkAt=0;
    }
    // A6 SDK | @a6wzneihe
    A6CInternal::A6CFrame A6C_poll(std::shared_ptr<const A6CInput::A6CBinding> active){
        const int requested=active?active->pid:0;
        A6CInternal::A6CFrame f;f.pid=requested;f.sequence=++sequence;bytes=0;budget=786432;guards.clear();const U now=A6CInternal::A6C_monotonic_ms();
        if(pid==requested&&binding==active&&now<retryAt){auto cached=waitingFrame;cached.sequence=f.sequence;cached.bytes_read=0;return cached;}
        std::map<U,Bytes> bindingGuards;
        try {
            A6C_ready(requested>0,A6_STATUS_TEXT("C waiting for process"));
            if(pid!=requested||binding!=active)A6C_bind(std::move(active));
            auto roster=A6C_targets();const U current=A6C_ptr(binding->access_slot,true);
            if(entry&&current!=entry)A6C_drop();entry=current;A6C_ready(entry&&A6C_mapped(entry,8,'x'),A6_STATUS_TEXT("C getter absent"));
            if(!complete)A6C_discover();
            if(now>=checkAt){for(const auto& [pc,value]:code)A6C_ready(A6C_read(pc,value.size())==value,A6_STATUS_TEXT("C code changed"));for(auto [a,v]:branches)A6C_ready(A6C_get<U>(a)==v,A6_STATUS_TEXT("C branch changed"));checkAt=now+3000;}
            bool protectedCoordinates=false;
            for(U flag:gateFlags){const auto value=A6C_get<std::uint8_t>(flag,true);A6C_ready(value<=1,A6_STATUS_TEXT("C representation invalid"));protectedCoordinates|=value!=0;}
            if(plainSlot)A6C_ready(A6C_ptr(plainSlot,true)==plainFunction,A6_STATUS_TEXT("C original accessor replaced"));
            // Keep the verified representation on transient failures so the
            // existing display-only hold can bridge a publication window.
            // No failed frame receives coordinates or a ready status.
            f.mode=protectedCoordinates?A6CInternal::A6CMode::encrypted:A6CInternal::A6CMode::plain;
            bindingGuards=guards;
            for(U flag:gateFlags)bindingGuards.erase(flag);
            std::array<U,35> words{};std::array<unsigned,5> rowFor{};
            if(protectedCoordinates){
                A6C_ready(A6C_get<std::uint32_t>(count,true)==5,A6_STATUS_TEXT("C published roster incomplete"));std::set<unsigned> occupied;
                for(unsigned i=0;i<5;++i){unsigned matches=0;
                    for(unsigned row=0;row<5;++row)for(U field:ownerFields)if(A6C_ptr(origin+row*stride+field,true)==roster[i].owner){rowFor[i]=row;++matches;}
                    A6C_ready(matches==1&&occupied.insert(rowFor[i]).second,A6_STATUS_TEXT("C row owner not unique"));
                }
                const auto p0=A6C_get<std::uint8_t>(phase);auto before=A6C_read(bank,280);auto after=A6C_read(bank,280);const auto p1=A6C_get<std::uint8_t>(phase);
                A6C_ready(p0<=1&&p0==p1&&before==after,A6_STATUS_TEXT("C publication busy"));
                f.monotonic_ms=A6CInternal::A6C_monotonic_ms();std::memcpy(words.data(),before.data(),280);
                if(p0){
                    bool accepted=false;std::string executionFailure;
                    for(U handler:handlers){
                        try {
                            machine->A6C_freshData();machine->A6C_setSignal(handler,[this](U a){return A6C_fault(a);});machine->A6C_provide(bank,before.data(),before.size());
                            const U status=machine->A6C_run(decode.fn,decode.args[0],decode.args[1],decode.args[2],decode.args[3]);
                            machine->A6C_read(bank,words.data(),280);
                            if(status==1&&A6C_valid(words)){
                                // Independent reads must reproduce the entire saved
                                // publication. Guest bookkeeping counters may change;
                                // they must not turn a correct result into a data gap.
                                const auto first=words;
                                machine->A6C_freshData();machine->A6C_provide(bank,before.data(),before.size());
                                const U again=machine->A6C_run(decode.fn,decode.args[0],decode.args[1],decode.args[2],decode.args[3]);
                                machine->A6C_read(bank,words.data(),280);
                                if(again==1&&words==first){accepted=true;handlers={handler};break;}
                            }
                        }catch(const std::exception& e){executionFailure=e.what();}
                    }
                    if(!accepted&&!executionFailure.empty())throw Retry(executionFailure);
                    A6C_ready(accepted,A6_STATUS_TEXT("C execution snapshot changed"));
                }
                A6C_ready(A6C_valid(words),A6_STATUS_TEXT("C decoded publication invalid"));
            }
            for(unsigned i=0;i<5;++i){const auto& a=roster[i];auto& p=f.points[i];p.actor=a.actor;p.object=a.owner;p.actor_key=a.key;p.camp=a.camp;
                const U record=A6C_ptr(a.owner+displacement,true);
                if(protectedCoordinates){const U pair=words[rowFor[i]*7];p.x=std::int32_t(pair);p.y=std::int32_t(pair>>32);p.height=A6C_get<std::int32_t>(record+4,true);p.record=bank+rowFor[i]*56;}
                else{auto raw=A6C_read(record,12,true);p.x=A6C_number<std::int32_t>(raw);p.height=A6C_number<std::int32_t>(raw,4);p.y=A6C_number<std::int32_t>(raw,8);p.record=record;}
                A6C_ready(std::abs(std::int64_t(p.height))<=1000000&&std::abs(std::int64_t(p.x))<=1000000&&std::abs(std::int64_t(p.y))<=1000000,A6_STATUS_TEXT("C coordinate domain"));
            }
            A6C_validate();f.count=5;f.status=A6CInternal::A6CStatusCode::ready;f.mode=protectedCoordinates?A6CInternal::A6CMode::encrypted:A6CInternal::A6CMode::plain;
            f.separate_encryption_status=true;f.observed_encryption=f.mode;f.encryption_observed_ms=now;if(!f.monotonic_ms)f.monotonic_ms=now;failures=0;retryAt=0;waitingFrame={};
        }catch(const BindingChanged& e){f.status=A6CInternal::A6CStatusCode::generation_changed;f.mode=A6CInternal::A6CMode::unknown;f.reason=A6CInternal::A6CReasonCode::identity_changed;f.detail=e.what();A6C_drop();retryAt=now+5;}
        catch(const ReadFailure& e){f.status=A6CInternal::A6CStatusCode::read_error;f.detail=e.what();retryAt=now+5;}
        catch(const Unsupported& e){f.status=A6CInternal::A6CStatusCode::unsupported;f.detail=e.what();A6C_drop();retryAt=now+1000;}
        catch(const std::exception& e){
            f.status=A6CInternal::A6CStatusCode::waiting;f.detail=e.what();f.reason=A6CInternal::A6CReasonCode::record_changed;
            // Publication rows and their values rotate independently of the
            // actor identity. They must agree for a new successful sample, but
            // only the stable binding and actual representation govern whether
            // the display can retain its previous, already verified sample.
            if(f.mode!=A6CInternal::A6CMode::unknown){
                try{
                    A6C_ready(!bindingGuards.empty(),A6_STATUS_TEXT("C binding unavailable"));
                    A6C_validate(bindingGuards);
                    bool stillProtected=false;
                    for(U flag:gateFlags){const auto value=A6C_get<std::uint8_t>(flag);A6C_ready(value<=1,A6_STATUS_TEXT("C representation invalid"));stillProtected|=value!=0;}
                    A6C_ready(f.mode==(stillProtected?A6CInternal::A6CMode::encrypted:A6CInternal::A6CMode::plain),A6_STATUS_TEXT("C representation changed"));
                }catch(const std::exception&){f.mode=A6CInternal::A6CMode::unknown;f.reason=A6CInternal::A6CReasonCode::identity_changed;}
            }
            retryAt=now+(++failures>=12?50:5);
        }
        if(f.status!=A6CInternal::A6CStatusCode::ready){f.points={};f.count=0;f.monotonic_ms=A6CInternal::A6C_monotonic_ms();}
        f.generation=generation;f.bytes_read=bytes;
        if(f.status!=A6CInternal::A6CStatusCode::ready)waitingFrame=f;
        return f;
    }
};
// A6 SDK | @a6wzneihe
A6CReader::A6CReader(std::shared_ptr<A6CInternal::A6CBackend> backend):impl_(std::make_unique<A6CImpl>(std::move(backend))){}
// A6 SDK | @a6wzneihe
A6CReader::~A6CReader()=default;
// A6 SDK | @a6wzneihe
A6CInternal::A6CFrame A6CReader::A6C_poll(std::shared_ptr<const A6CInput::A6CBinding> binding){return impl_->A6C_poll(std::move(binding));}
// A6 SDK | @a6wzneihe
void A6CReader::A6C_reset(){impl_->A6C_reset();}
}
