# A6 C SDK dependencies

A6 SDK channel: **@a6wzneihe**.

The A6 integration layer and coordinate module are supplied with source. The following third-party materials retain their original notices, licenses, symbols and API names:

- Capstone 5.0.6: BSD-style license; see `third_party/licenses/CAPSTONE-LICENSE.txt` and `CAPSTONE-LLVM.txt`.
- Unicorn 2.1.4, quiet build used by A6: GPL v2 and bundled component notices; see `third_party/licenses/UNICORN-COPYING.txt`, `UNICORN-GLIB.txt`, and `UNICORN-LGPL2.txt`. Corresponding source archive is included under `third_party/sources/`.

The Unicorn source archive omits the upstream precompiled ELF regression fixture. Source code and license notices are retained; this package contains no precompiled dependencies.

When redistributing the combined SDK, preserve the applicable licenses and corresponding source obligations. A6 branding does not replace third-party ownership or license terms.
