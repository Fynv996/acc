// A6 C SDK integration example | @a6wzneihe
#include "A6C.hpp"
#include <cstdio>

// A6 | @a6wzneihe: replace with the host project's exact memory reader.
static int A6C_HostRead(void*,int32_t,uint64_t,void*,size_t) { return 0; }

// A6 | @a6wzneihe: the host discovers and validates every runtime input.
// The guards' byte arrays must remain alive until A6C_Bind returns.
static int A6C_HostBinding(void*,A6C_Binding*) { return 0; }

// A6 | @a6wzneihe: this template never selects or attaches to a process.
int main() {
    A6C_Config config{};config.struct_size=sizeof(config);config.abi_version=A6C_ABI_VERSION;
    config.read_memory=A6C_HostRead;
    A6C_Binding input{};input.struct_size=sizeof(input);input.abi_version=A6C_ABI_VERSION;
    if(A6C_HostBinding(config.context,&input)!=1) {
        std::fprintf(stderr,"A6 SDK: implement the host input adapter before running.\n");return 2;
    }
    try {
        A6C::A6C_Session session(config);session.A6C_Bind(input);
        const auto frame=session.A6C_Poll();
        std::printf("A6 status=%u count=%u epoch=%llu\n",frame.status,frame.count,(unsigned long long)frame.binding_epoch);
        if(frame.status!=A6C_READY||frame.count!=A6C_MAX_POINTS)return 1;
        for(const auto& point:frame.points)
            std::printf("A6 target=%u x=%d z=%d height=%d\n",point.actor_key,point.x,point.z,point.height);
    }catch(const std::exception& error){std::fprintf(stderr,"%s\n",error.what());return 1;}
    return 0;
}
