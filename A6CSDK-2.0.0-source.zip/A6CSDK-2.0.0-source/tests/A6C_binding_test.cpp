// A6 C SDK portable validation tests | @a6wzneihe
#include "internal/A6C_Binding.hpp"
#include <cassert>
#include <cstdint>
#include <stdexcept>
// A6 | @a6wzneihe: reject a malformed input without reading any process.
static bool A6C_Reject(const A6C_Binding& input) {
    try{(void)A6CInput::A6C_CopyBinding(input);return false;}
    catch(const std::invalid_argument&){return true;}
}
// A6 | @a6wzneihe: exercise ownership, range, identity and epoch boundaries.
int main() {
    A6C_Binding input{};input.struct_size=sizeof(input);input.abi_version=A6C_ABI_VERSION;
    input.pid=123;input.start_ticks=42;input.epoch=1;input.target_count=5;
    input.access_slot=0x10000;input.publish_slot=0x10008;
    std::uint64_t expected=77;A6C_Guard guard{0x10010,&expected,sizeof(expected)};
    input.guards=&guard;input.guard_count=1;
    for(unsigned i=0;i<5;++i)input.targets[i]={i+1,2,0x20000+i*0x100,0x30000+i*0x100};
    const auto first=A6CInput::A6C_CopyBinding(input);
    expected=88;assert(first->guards[0].expected[0]==77);
    const auto changed=A6CInput::A6C_CopyBinding(input);
    assert(!A6CInput::A6C_SameBinding(*first,*changed)&&A6CInput::A6C_EpochConflict(*first,*changed));
    ++input.epoch;const auto next=A6CInput::A6C_CopyBinding(input);
    assert(!A6CInput::A6C_EpochConflict(*first,*next));
    assert(A6CInput::A6C_SameBinding(*next,*A6CInput::A6C_CopyBinding(input)));
    auto bad=input;bad.abi_version=1;assert(A6C_Reject(bad));
    bad=input;bad.target_count=4;assert(A6C_Reject(bad));
    bad=input;bad.pid=0;assert(A6C_Reject(bad));
    bad=input;bad.start_ticks=0;assert(A6C_Reject(bad));
    bad=input;bad.epoch=0;assert(A6C_Reject(bad));
    bad=input;bad.access_slot=1;assert(A6C_Reject(bad));
    bad=input;bad.publish_slot=bad.access_slot;assert(A6C_Reject(bad));
    bad=input;bad.targets[1].actor_key=bad.targets[0].actor_key;assert(A6CInput::A6C_CopyBinding(bad));
    bad=input;bad.targets[1].object_address=bad.targets[0].object_address;assert(A6C_Reject(bad));
    bad=input;bad.targets[1].actor_address=bad.targets[0].actor_address;assert(A6C_Reject(bad));
    bad=input;bad.targets[1].camp=1;assert(A6C_Reject(bad));
    bad=input;bad.guard_count=0;assert(A6C_Reject(bad));
    bad=input;bad.guard_count=65;assert(A6C_Reject(bad));
    A6C_Guard invalid=guard;invalid.expected=nullptr;bad=input;bad.guards=&invalid;assert(A6C_Reject(bad));
    invalid=guard;invalid.size=0;assert(A6C_Reject(bad));
    invalid=guard;invalid.size=257;assert(A6C_Reject(bad));
    invalid=guard;invalid.address=0x00fffffffffffffeULL;assert(A6C_Reject(bad));
    A6C_Guard overlap[2]={guard,guard};bad=input;bad.guards=overlap;bad.guard_count=2;assert(A6C_Reject(bad));
    return 0;
}
