// A6 C SDK synthetic-memory end-to-end contract checks | @a6wzneihe
#include "A6C.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>
struct A6C_Fixture {
    std::vector<unsigned char> memory=std::vector<unsigned char>(0x80000);
    std::uint64_t ticks=1234;
    unsigned reads=0;
    // A6 | @a6wzneihe: write only to this test's synthetic byte array.
    template<class T> void A6C_Put(std::uint64_t at,T value){std::memcpy(memory.data()+at,&value,sizeof(value));}
};
// A6 | @a6wzneihe: this reader never accesses any process or device.
static int A6C_Read(void* context,int32_t pid,uint64_t at,void* out,size_t size) {
    auto& f=*static_cast<A6C_Fixture*>(context);++f.reads;
    if(pid!=123||at>f.memory.size()||size>f.memory.size()-at)return 0;
    std::memcpy(out,f.memory.data()+at,size);return 1;
}
// A6 | @a6wzneihe: a deterministic synthetic process generation.
static int A6C_Identity(void* context,int32_t pid,uint64_t* ticks) {
    *ticks=static_cast<A6C_Fixture*>(context)->ticks;return pid==123?1:0;
}
// A6 | @a6wzneihe: disjoint data/code mappings supplied without OS lookup.
static int A6C_Maps(void*,int32_t pid,A6C_MapSink sink,void* context) {
    if(pid!=123)return 0;
    const A6C_Mapping data{0x10000,0x60000,0,"rw-p",""};
    const A6C_Mapping code{0x70000,0x71000,0,"r-xp",""};
    return sink(context,&data)&&sink(context,&code);
}
// A6 | @a6wzneihe: exercise the actual C core with synthetic AArch64 input.
int main() {
    assert(A6C_GetAbiVersion()==2&&std::strcmp(A6C_GetChannel(),"@a6wzneihe")==0);
    A6C_Handle* handle=reinterpret_cast<A6C_Handle*>(1);
    assert(A6C_Create(nullptr,&handle)==A6C_INVALID_ARGUMENT&&handle==nullptr);
    A6C_Fixture fixture;
    A6C_Config config{};config.struct_size=sizeof(config);config.abi_version=A6C_ABI_VERSION;
    assert(A6C_Create(&config,&handle)==A6C_INVALID_ARGUMENT&&handle==nullptr);
    config.context=&fixture;config.read_memory=A6C_Read;config.read_identity=A6C_Identity;config.list_mappings=A6C_Maps;
    assert(A6C_Create(&config,&handle)==A6C_OK&&handle);
    A6C_Frame frame{};frame.struct_size=sizeof(frame);frame.points[0].x=999;
    assert(A6C_Poll(handle,&frame)==A6C_NOT_BOUND&&frame.count==0&&frame.points[0].x==0);
    A6C_Binding input{};input.struct_size=sizeof(input);input.abi_version=A6C_ABI_VERSION;
    input.pid=123;input.start_ticks=fixture.ticks;input.epoch=1;input.target_count=A6C_MAX_POINTS;
    input.access_slot=0x10000;input.publish_slot=0x10008;
    std::uint64_t expected=7;
    A6C_Guard guard{0x10010,&expected,sizeof(expected)};input.guards=&guard;input.guard_count=1;
    fixture.A6C_Put<std::uint64_t>(input.access_slot,0x70000);
    fixture.A6C_Put<std::uint64_t>(input.publish_slot,0x70000);
    fixture.A6C_Put(guard.address,expected);
    fixture.A6C_Put<std::uint32_t>(0x70000,0xf9400c00); // A6: ldr x0, [x0, #24].
    fixture.A6C_Put<std::uint32_t>(0x70004,0xd65f03c0); // A6: ret.
    for(unsigned i=0;i<A6C_MAX_POINTS;++i) {
        auto& target=input.targets[i];target.actor_key=i+1;target.camp=2;
        target.actor_address=0x20000+i*0x100;target.object_address=0x30000+i*0x100;
        const std::uint64_t record=0x40000+i*0x100;
        fixture.A6C_Put(target.object_address+24,record);
        fixture.A6C_Put<std::int32_t>(record,100+i);
        fixture.A6C_Put<std::int32_t>(record+4,200+i);
        fixture.A6C_Put<std::int32_t>(record+8,300+i);
    }
    assert(A6C_Bind(handle,&input)==A6C_OK);
    expected=99; // A6: Bind must own a copy, not retain this caller buffer.
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK);
    assert(frame.status==A6C_READY&&frame.count==5&&frame.binding_epoch==1);
    for(unsigned i=0;i<5;++i)assert(frame.points[i].x==int(100+i)&&frame.points[i].height==int(200+i)&&frame.points[i].z==int(300+i));
    const auto generation=frame.generation;
    expected=7;assert(A6C_Bind(handle,&input)==A6C_OK);
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK&&frame.generation==generation);
    expected=8;assert(A6C_Bind(handle,&input)==A6C_INVALID_BINDING);
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK&&frame.status==A6C_READY);
    fixture.A6C_Put<std::uint64_t>(guard.address,8);
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK);
    assert(frame.status==A6C_GENERATION_CHANGED&&frame.count==0&&frame.points[0].x==0);
    input.epoch=2;assert(A6C_Bind(handle,&input)==A6C_OK);
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK&&frame.status==A6C_READY&&frame.binding_epoch==2);
    ++fixture.ticks;frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_OK);
    assert(frame.status==A6C_GENERATION_CHANGED&&frame.count==0);
    assert(A6C_Reset(handle)==A6C_OK);
    frame.struct_size=sizeof(frame);assert(A6C_Poll(handle,&frame)==A6C_NOT_BOUND&&frame.count==0);
    assert(fixture.reads>0);A6C_Destroy(handle);A6C_Destroy(nullptr);
    return 0;
}
