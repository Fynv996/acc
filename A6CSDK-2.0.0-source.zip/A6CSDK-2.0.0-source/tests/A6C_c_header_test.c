/* A6 C SDK C-language compatibility check | @a6wzneihe */
#include "A6C.h"
_Static_assert(A6C_MAX_POINTS==5,"A6 point count contract");
_Static_assert(sizeof(((A6C_Point*)0)->x)==4,"A6 coordinate width");
/* A6 | @a6wzneihe: bind declarations from a pure C translation unit. */
int A6C_CompileCHeader(void) {
    A6C_Frame frame={0};frame.struct_size=sizeof(frame);
    return A6C_GetAbiVersion()==A6C_ABI_VERSION&&frame.struct_size>0;
}
