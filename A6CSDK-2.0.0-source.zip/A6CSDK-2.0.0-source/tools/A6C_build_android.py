"""A6 C SDK Android build entry. Channel: @a6wzneihe"""
from pathlib import Path
import argparse
import os
import subprocess


def A6C_main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ndk',type=Path,required=True)
    parser.add_argument('--cmake',required=True)
    parser.add_argument('--ninja',required=True)
    parser.add_argument('--build',type=Path,required=True)
    args=parser.parse_args()
    source=Path(__file__).resolve().parents[1]
    args.build.mkdir(parents=True,exist_ok=True)
    temporary=args.build/'temp';temporary.mkdir(exist_ok=True)
    environment=dict(os.environ,TEMP=str(temporary),TMP=str(temporary))
    host='windows-x86_64' if os.name=='nt' else 'linux-x86_64'
    suffix='.exe' if os.name=='nt' else ''
    strings=args.ndk/'toolchains/llvm/prebuilt'/host/'bin'/('llvm-strings'+suffix)
    if strings.is_file():environment['STRINGS']=strings.as_posix()
    # A6 | @a6wzneihe: this mobile build uses bundled compatibility sources.
    # Disable discovery of unrelated host packages during cross compilation.
    environment['PKG_CONFIG']='false'
    subprocess.run([args.cmake,'-S',str(source),'-B',str(args.build),'-G','Ninja',
        '-DCMAKE_MAKE_PROGRAM='+args.ninja,'-DCMAKE_TOOLCHAIN_FILE='+str(args.ndk/'build/cmake/android.toolchain.cmake'),
        '-DANDROID_ABI=arm64-v8a','-DANDROID_PLATFORM=android-24','-DANDROID_STL=c++_static',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],check=True,env=environment)
    subprocess.run([args.cmake,'--build',str(args.build),'--parallel','4'],check=True,env=environment)


if __name__=='__main__':
    A6C_main()
