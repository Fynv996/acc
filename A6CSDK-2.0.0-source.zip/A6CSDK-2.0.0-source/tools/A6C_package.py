"""A6 C SDK source-only archive builder. Channel: @a6wzneihe"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile

VERSION = '2.0.0'


def A6C_hash(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def A6C_main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[1]
    root = args.output / ('A6CSDK-' + VERSION + '-source')
    if root.exists():
        raise RuntimeError('A6 source package exists; inspect before replacing')
    root.mkdir(parents=True)
    for name in ('include', 'src', 'examples', 'tests', 'tools'):
        shutil.copytree(source / name, root / name,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.rollback*'))
    for name in ('include', 'licenses', 'sources'):
        shutil.copytree(source / 'third_party' / name, root / 'third_party' / name)
    for name in ('CMakeLists.txt', 'README.md', 'THIRD_PARTY_NOTICES.md', 'A6C_ORIGIN.json', 'A6C_BRANDING.json'):
        shutil.copy2(source / name, root / name)
    for path in root.rglob('*'):
        if not path.is_file():
            continue
        data = path.read_bytes()
        if path.suffix.lower() in ('.a', '.so', '.dll', '.exe', '.o', '.obj', '.pdb', '.pyc'):
            raise RuntimeError('Compiled artifact in source package: ' + str(path.relative_to(root)))
        if data.startswith((b'\x7fELF', b'!<arch>\n', b'MZ')):
            raise RuntimeError('Compiled payload in source package: ' + str(path.relative_to(root)))
    manifest = {
        'sdk': 'A6 C SDK', 'version': VERSION, 'abi_version': 2,
        'channel': '@a6wzneihe', 'source_only': True,
        'runtime_binding_required': True, 'embedded_game_locator': False,
        'network': False, 'logging': False,
        'files': {p.relative_to(root).as_posix(): {'sha256': A6C_hash(p), 'bytes': p.stat().st_size}
                  for p in sorted(root.rglob('*')) if p.is_file()}
    }
    (root / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    checks = [A6C_hash(p) + '  ' + p.relative_to(root).as_posix()
              for p in sorted(root.rglob('*')) if p.is_file()]
    (root / 'SHA256SUMS.txt').write_text('\n'.join(checks) + '\n', encoding='utf8')
    archive = args.output / (root.name + '.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                output.write(path, path.relative_to(args.output).as_posix())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise RuntimeError('A6 archive integrity failure')
    report = {'archive': str(archive), 'sha256': A6C_hash(archive), 'bytes': archive.stat().st_size,
              'source_only': True, 'files': len(checks) + 1, 'embedded_game_locator': False}
    (args.output / (root.name + '-report.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    A6C_main()
