/* A6 C SDK 2.0.0 | Official channel: @a6wzneihe */
#ifndef A6C_SDK_H
#define A6C_SDK_H
#include <stddef.h>
#include <stdint.h>
#if defined(_WIN32) && defined(A6C_BUILD_SHARED)
#define A6C_API __declspec(dllexport)
#elif defined(__GNUC__)
#define A6C_API __attribute__((visibility("default")))
#else
#define A6C_API
#endif
#ifdef __cplusplus
extern "C" {
#endif

#define A6C_ABI_VERSION 2u
#define A6C_MAX_POINTS 5u
typedef struct A6C_Handle A6C_Handle;
enum A6C_Error { A6C_OK=0, A6C_INVALID_ARGUMENT=1, A6C_INVALID_BINDING=2,
    A6C_NO_MEMORY=3, A6C_BUSY=4, A6C_INTERNAL_ERROR=5, A6C_NOT_BOUND=6 };
enum A6C_Status { A6C_WAITING=0, A6C_READY=1, A6C_GENERATION_CHANGED=2,
    A6C_UNSUPPORTED=3, A6C_READ_ERROR=4 };
enum A6C_Mode { A6C_UNKNOWN=0, A6C_PLAIN=1, A6C_PROTECTED=2 };
enum A6C_PointFlags { A6C_HEIGHT_VALID=1u };

typedef struct A6C_Mapping {
    uint64_t start, end, file_offset;
    const char* permissions;
    const char* path;
} A6C_Mapping;
/* A6 | @a6wzneihe: callbacks return 1 only for complete synchronous success.
   Preserve repeated reads and their order. No target-write callback exists. */
typedef int (*A6C_MapSink)(void* sink_context,const A6C_Mapping* mapping);
typedef int (*A6C_ReadMemory)(void* context,int32_t pid,uint64_t address,void* output,size_t size);
typedef int (*A6C_ListMappings)(void* context,int32_t pid,A6C_MapSink sink,void* sink_context);
typedef int (*A6C_ReadIdentity)(void* context,int32_t pid,uint64_t* start_ticks);

typedef struct A6C_Config {
    uint32_t struct_size, abi_version;
    void* context;
    A6C_ReadMemory read_memory; /* Required: integrate the host's memory reader. */
    A6C_ListMappings list_mappings; /* Optional: default reads /proc/PID/maps. */
    A6C_ReadIdentity read_identity; /* Optional: default reads /proc/PID/stat. */
} A6C_Config;

/* A6 | @a6wzneihe: all addresses below are current-process absolute addresses
   supplied by the host. The SDK has no built-in game locator. */
typedef struct A6C_Target {
    uint32_t actor_key, camp;
    uint64_t actor_address, object_address;
} A6C_Target;

/* A6 | @a6wzneihe: immutable expected bytes, copied by A6C_Bind. The host must
   cover the current session, roster, object ownership and selected entries. */
typedef struct A6C_Guard {
    uint64_t address;
    const void* expected;
    size_t size;
} A6C_Guard;

typedef struct A6C_Binding {
    uint32_t struct_size, abi_version;
    int32_t pid;
    uint32_t target_count;
    uint64_t start_ticks, epoch;
    uint64_t access_slot, publish_slot;
    A6C_Target targets[A6C_MAX_POINTS];
    const A6C_Guard* guards;
    size_t guard_count;
} A6C_Binding;

typedef struct A6C_Point {
    uint32_t actor_key, camp;
    int32_t x, height, z;
    uint32_t flags;
    uint64_t actor_address, owner_address, record_address;
} A6C_Point;
typedef struct A6C_Frame {
    uint32_t struct_size, abi_version;
    uint32_t status, mode, observed_mode, count;
    int32_t pid;
    uint32_t reason;
    uint64_t generation, binding_epoch, sequence, monotonic_ms, observed_ms, bytes_read, detail_code;
    A6C_Point points[A6C_MAX_POINTS];
} A6C_Frame;

/* A6 | @a6wzneihe: retrieve the stable C ABI version. */
A6C_API uint32_t A6C_GetAbiVersion(void);
/* A6 | @a6wzneihe: retrieve the SDK version and built-in attribution. */
A6C_API const char* A6C_GetVersion(void);
/* A6 | @a6wzneihe: retrieve the channel watermark without creating a session. */
A6C_API const char* A6C_GetChannel(void);
/* A6 | @a6wzneihe: copy callbacks and create an unbound isolated session. */
A6C_API int A6C_Create(const A6C_Config* config,A6C_Handle** output);
/* A6 | @a6wzneihe: stop all calls to this handle before destruction. */
A6C_API void A6C_Destroy(A6C_Handle* handle);
/* A6 | @a6wzneihe: synchronous worker-thread call; inspect status and count.
   Failure frames never contain retained coordinates. Initialize struct_size. */
A6C_API int A6C_Poll(A6C_Handle* handle,A6C_Frame* output);
/* A6 | @a6wzneihe: clear the binding and private execution state. */
A6C_API int A6C_Reset(A6C_Handle* handle);
/* A6 | @a6wzneihe: copy checked inputs; rejection preserves the old binding.
   Identical input is idempotent. Changed input requires a new epoch. */
A6C_API int A6C_Bind(A6C_Handle* handle,const A6C_Binding* binding);
/* A6 | @a6wzneihe: generic API error text; no algorithm trace is emitted. */
A6C_API const char* A6C_GetErrorName(int error);

#ifdef __cplusplus
}
#endif
#endif
