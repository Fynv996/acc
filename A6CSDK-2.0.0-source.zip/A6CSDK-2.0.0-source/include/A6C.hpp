// A6 C SDK | C++17 ownership wrapper | @a6wzneihe
#pragma once
#include "A6C.h"
#include <stdexcept>
#include <utility>
namespace A6C {
class A6C_Session {
    A6C_Handle* A6C_handle_=nullptr;
public:
    // A6 | @a6wzneihe: callbacks are copied by the C interface.
    explicit A6C_Session(const A6C_Config& config) {
        const int error=A6C_Create(&config,&A6C_handle_);
        if(error!=A6C_OK)throw std::runtime_error(A6C_GetErrorName(error));
    }
    // A6 SDK | @a6wzneihe
    ~A6C_Session(){A6C_Destroy(A6C_handle_);}
    A6C_Session(const A6C_Session&)=delete;
    A6C_Session& operator=(const A6C_Session&)=delete;
    // A6 SDK | @a6wzneihe
    A6C_Session(A6C_Session&& other)noexcept:A6C_handle_(std::exchange(other.A6C_handle_,nullptr)){}
    // A6 SDK | @a6wzneihe
    A6C_Session& operator=(A6C_Session&& other)noexcept {
        if(this!=&other){A6C_Destroy(A6C_handle_);A6C_handle_=std::exchange(other.A6C_handle_,nullptr);}return *this;
    }
    // A6 | @a6wzneihe: return one checked frame without display interpolation.
    A6C_Frame A6C_Poll() {
        A6C_Frame frame{};frame.struct_size=sizeof(frame);
        const auto error=::A6C_Poll(A6C_handle_,&frame);
        if(error!=A6C_OK)throw std::runtime_error(A6C_GetErrorName(error));return frame;
    }
    // A6 | @a6wzneihe: provide current targets, execution entries and guards.
    void A6C_Bind(const A6C_Binding& binding) {
        const int e=::A6C_Bind(A6C_handle_,&binding);
        if(e!=A6C_OK)throw std::runtime_error(A6C_GetErrorName(e));
    }
    // A6 | @a6wzneihe: explicit session reset.
    void A6C_Reset(){const int e=::A6C_Reset(A6C_handle_);if(e!=A6C_OK)throw std::runtime_error(A6C_GetErrorName(e));}
};
}
